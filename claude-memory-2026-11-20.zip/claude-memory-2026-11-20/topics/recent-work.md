---
name: "recent-work"
description: "Recent work activity not scoped to a standing project"
---

- Prepared USM oral exposition study guides — on crisis management (SHEIN case) for Relaciones Públicas I, and on El Discurso and Tipos de Discurso Empresarial for Fundamentos Organizacionales — requesting linear bullet-point formats, example spoken phrases, and real-world cases
- Produced a group marketing campaign presentation on a corporate bazar event for Océano Pacífico/Camor International, covering objectives, results, and metrics sections
- Produced an executive KFC launch marketing campaign presentation for Anzoátegui (tagline: "Ya llegó tu Bucket favorito"), working through PowerPoint, HTML/PDF, and Canva workflows
- Worked on a Llégate campaign calendar planning task
- Invitada por un profesor de Turismo de la UDO a dar una charla motivacional a sus estudiantes (nov 2026) sobre salir adelante con el turismo y la creación de contenido; cuenta que empezó su marca yendo en autobús a grabar
