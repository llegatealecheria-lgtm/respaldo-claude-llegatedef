---
name: "interests"
description: "Naylu's personal interests"
---

- Interested in her region's culture and landscape; applied to a "Hero" program that would take her to Canaima, Venezuela
