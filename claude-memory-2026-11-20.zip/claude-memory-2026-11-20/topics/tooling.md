---
name: "tooling"
description: "Core platforms and tools Naylu works across"
---

- Works across Canva, Google Drive, Notion, and spreadsheet tools as core platforms
- Sought architectural advice on Claude tool usage — separate Excel vs. Google Sheets skills recommended
- The `PM-expert` skill contains her full professional profile (employers, dates, PM framing decisions) in `references/perfil-jera-larez.md` — consult it directly rather than re-asking from scratch
- Built a structured Claude platform reference document in Spanish from training sessions led by an instructor named Ángel, covering models, tools, Automatizaciones, Cowork, MCP, and platform concepts
