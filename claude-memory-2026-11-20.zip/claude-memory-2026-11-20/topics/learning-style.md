---
name: "learning-style"
description: "How Naylu learns and retains information"
---

- Linear, repetition-based learning style
- Retains information better through bullet points, comparative layouts, and concise labeled formats rather than dense prose
