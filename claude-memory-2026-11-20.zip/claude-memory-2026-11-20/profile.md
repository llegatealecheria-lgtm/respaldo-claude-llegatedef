---
name: "profile"
description: "Who Naylu is — marketing student and hospitality business owner in Venezuela"
---

- Name: Naylu
- Marketing student at Universidad Santa María (USM), Núcleo Oriente
- Owner and manager of "Llégate a Lechería," a vacation and corporate hospitality business in Lechería, Anzoátegui, Venezuela
- Does content and editorial work for Visuarte, a digital media outlet targeting Gen Z in Latin America
- Based in the Lechería/Puerto La Cruz area, Venezuela
