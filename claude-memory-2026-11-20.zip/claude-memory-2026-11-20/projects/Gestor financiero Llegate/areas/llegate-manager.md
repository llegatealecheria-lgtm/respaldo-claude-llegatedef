---
name: "llegate-manager"
description: "Llégate Manager — plataforma propia (CRM, disponibilidad, cotizaciones, reservas, finanzas) que Naylu está diseñando para Llégate a Lechería"
---

- Naylu está diseñando y desarrollando "Llégate Manager", sistema propio para [[llegate-a-lecheria]] que une CRM, disponibilidad centralizada de ~40 propiedades, cotizador, reservas, finanzas, portal de propietarios e integraciones (WhatsApp, Instagram, TikTok, Google Calendar)
- Stack elegido: Lovable + React/TypeScript + Supabase (Auth, Storage, Edge Functions, RLS); presupuesto de herramientas ~US$50–100/mes
- Trabaja por fases: análisis primero, sin programar; datos ficticios y sin conectar el WhatsApp operativo hasta aprobar pruebas
- Equipo comercial de 2–3 asesoras; Gera atiende solicitudes por WhatsApp (un solo número comercial)
- Nov 2026: empezó por el módulo financiero en Lovable (prototipo, sin CRM/reservas/calendario todavía); prioriza cálculos correctos y auditables, sin datos ficticios presentados como reales
- Decidió que el Sheets "Producción Llégate a Lechería" siga siendo la fuente de verdad y se sincronice automáticamente hacia la app (Sheets → Supabase)
- Nov 2026: ya es propietaria del Sheets "Producción Llégate a Lechería" y tiene otras automatizaciones de Apps Script en ese mismo proyecto (no borrarlas al agregar scripts nuevos)
- Convención del Sheet "Producción": COMPLETADO = "Sí" significa que la comisión de Llégate ya fue cobrada; "No" = comisión aún pendiente por cobrar a Llégate (no indica si el propietario fue pagado)
- Convención del Sheet: cuando el cliente paga el resto directo al propietario se registra con método "Pagado al propietario"; las REF solo llevan los 4 últimos dígitos cuando el pago llegó a Llégate
