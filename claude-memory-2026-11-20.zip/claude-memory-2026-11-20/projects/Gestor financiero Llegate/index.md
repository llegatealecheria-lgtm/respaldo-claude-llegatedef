---
name: "Gestor financiero Llegate"
description: "Gestor financiero Llegate — Google Sheets/Apps Script finance tracking and automation for Naylu's rental intermediary business."
---

