---
name: "overview"
description: "Llégate a Lechería rental intermediary business — model, collaborators, workbooks, and current state of the finance automation work"
---

- Naylu runs Llégate a Lechería, a vacation and corporate rental intermediary business in Venezuela
- She does not manage properties directly — the business is an intermediary
- Revenue model: a fixed commission per night (tiered by property capacity) plus a fixed management fee per booking
- Earnings are tracked in USD/USDT even though some charges are denominated in other currencies
- Core financial goal: clear visibility into weekly cash flow (income vs. expenses, free cash) and monthly projections
- Jera is the sales advisor; she receives 20% commission on Naylu's earnings, tracked and paid weekly

## Systems and workbooks
- Google Sheets is the primary operational platform for all financial tracking
- Income is now registered in "Producción Llegate a Lechería" (one tab per month), replacing "Ingresos Llegate"; the weekly agent should read from Producción
- Wants the dashboard from September 2026 onward to come only from Producción, replacing the earlier September entries
- Commission collection: usually discounts 1 night of commission at booking, rest is pending until COMPLETADO = Sí; December bookings are paid ~half upfront, so she wants them flagged in red to enter the pending amount manually (depends on owner)
- Flujos de cobro (varían por reserva, según la nota bajo cada confirmación en WhatsApp): abono a Llégate y el resto lo paga el cliente al propietario; o todo a Llégate y ella pasa la parte del propietario; o se descuenta toda la comisión del abono. A veces el propietario paga aparte una comisión pendiente
- Nunca retiene dinero del propietario: lo que le corresponde lo transfiere el mismo día
- COMPLETADO = Sí → la comisión de Llégate está cobrada completa; No → aún le deben comisión (al propietario ya se le pagó)
- Convenciones en Producción: método "Pagado al propietario" cuando el cliente pagó directo al propietario (sin REF); REF solo con los 4 últimos dígitos cuando el propietario le paga a Llégate; columna COMISIÓN PAGADA con formato "Reserva: $X (ref) + Extra: $Y (ref)" para conciliación
- Las reservas entran a Producción por una automatización: se pasa la confirmación de reserva a Telegram con la comisión ganada y se registra sola en el Sheet
- Cancelaciones: Llégate se queda su parte del abono (una noche o el 50%) y el propietario la suya; se marca "Cancelada" en COMISIÓN PAGADA. La moneda real de las reservas es el euro
- "Dashboard_llegate_DEF" — aggregated financial dashboard covering income, expenses, ROI, and cushion (colchón) tracking
- "Ingresos 2026" is a separate Excel file from "Dashboard_llegate_DEF" (not a tab within it)
- "presupuesto madre" — personal budget file, kept separate from business finances
- Llégate-related entries appearing in personal tracking files should be excluded from personal budget automation
- Google Apps Script runs the weekly automation agent for income registration
- Google Drive is used for file storage; Claude accesses files via Drive tools (search → download → edit → re-upload or deliver via present_files)
- openpyxl is used for xlsx editing in Claude's environment: requires `copy()` for styles, `unmerge_cells()` before writing into merged zones, and a dual-load pattern (`data_only=False` for formulas, `data_only=True` for values)
- Recalc script at `/mnt/skills/public/xlsx/scripts/recalc.py` validates xlsx files after edits
- Skill packaging uses `package_skill.py` from `/mnt/skills/examples/skill-creator`; the description field has a 1024-character hard limit
- Three Claude skills exist for Llégate with explicit non-overlap boundaries: `finanzas-llegate` (cash flow, projections), `arquitecto-de-google-sheets` (structure/formulas), `analista-de-mercado-llegate` (pricing/benchmarking)

## Current state — business finance automation (primary active work)
- A Google Apps Script weekly automation agent is in development (reached v5+) to register income from the manual "Ingresos Llegate" sheet into the dashboard's "Ingresos 2026" aggregation sheet
- Each reservation splits into a "Reserva nueva" portion (paid immediately) and a "Pendiente" portion, marked pending until the check-in date passes and INGRESO PENDIENTE is manually set to 0
- Payment method maps to currency buckets: PM → Bs; Binance/USDT → USDT; Zelle/Efectivo/Transferencia → Divisas
- A ledger approach with three helper columns in "Ingresos 2026" (Clave auto, Origen auto, Tipo auto) prevents duplication across runs
- Unique reservation key = normalized cliente + propiedad + fecha reserva
- Jera's commissions register as weekly grouped totals (using the integer floor of her Semana column), always marked Pagado
- Bugs fixed through v5: timezone crash in date formatting (replaced with a custom `_ymd_()` function); double-counting of the "nueva" amount when pending clears (fixed with a frozen pending amount); CONTROL COMISIONES table header now found by dynamic scanning instead of a hardcoded column

## Current state — dashboard workbook (recently repaired and expanded)
- Fixed SUMIFS range caps and month-criteria errors in Egresos Mensuales and Dashboard
- Added August–December expense blocks
- Added "Incluir en ROI" column and a ROI tracking section
- Added "Origen del pago" column with values Caja del mes / Colchón / Aporte personal
- Added Saldo de Colchón acumulado section and Utilidad Operativa Ajustada metric
- Colchón tracking starts from zero at January 2026
- The majority of monthly expenses are funded from accumulated cushion rather than current-month revenue, making Utilidad Operativa Ajustada and Saldo de Colchón the central health metrics

## Current state — personal budget automation
- Repeatable workflow established: Naylu passes an updated personal expense file (Gastosssss) and Claude applies category mapping plus deduplication to transfer new entries into the monthly master budget, skipping already-recorded ones
- Ambiguous entries (e.g. mixed Ahorro cumpleaños / Cashea installments) are flagged for case-by-case review rather than auto-assigned
- Pre-existing anomalies in the master file (duplicates, off-system entries) are surfaced rather than silently deleted

## On the horizon
- Complete and stabilize the Apps Script automation agent for reliable weekly runs
- Add ongoing monthly tabs to "Ingresos Llegate" — an August 2026 template is established, and future months use a duplicable template sheet
- Continue personal budget sync as Naylu provides updated expense files
- Two dashboard items still unresolved: a January equipment expense with uncertain origin, and two Automatizaciones rows with swapped Mes values
