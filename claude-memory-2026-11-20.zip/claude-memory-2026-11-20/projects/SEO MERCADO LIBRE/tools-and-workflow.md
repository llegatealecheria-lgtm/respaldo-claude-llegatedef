---
name: "tools-and-workflow"
description: "File paths, packaging gotchas, research tools, and the skill-update protocol for this project"
---

- Skill file: `/mnt/skills/user/mercadolibre-copywriter-seo/SKILL.md`
- Output path: `/mnt/user-data/outputs/`
- Skill update protocol: when Naylu confirms a new rule or correction, update SKILL.md immediately and confirm it as saved
- Packaging: scripts must be copied to `/home/claude/pkgwork/` before running (original path not writable)
- Packaging: YAML description fields require block scalar syntax (`description: >`) to avoid parse errors with colons
- Trends tool: `tendencias.mercadolibre.com.ve` (Venezuela-specific, web panel only)
- Competitive research: direct ML listing fetch is blocked by robots.txt; indirect research via search results and Airbnb listings used as proxies
