---
name: "listing-rules-and-seo"
description: "Strict ML listing format, hard content prohibitions, SEO/keyword logic, ML policy constraints, and competitor-analysis rules — read before drafting any listing copy"
---

## Approved listing format (strict)
- 1. All-caps title header
- 2. Two highlight bullets
- 3. Short descriptive paragraph
- 4. "¿Qué ofrece este espacio?" section — plain text bullets listing all amenities together (no emojis, no sub-grouping)
- 5. Single closing line for reservation conditions

## Hard prohibitions in output
- No emojis
- No emotional hooks
- No closing invitation to message via ML
- These were explicitly rejected and must never appear in output

## ML policy constraints
- External links and handles (Instagram, WhatsApp, Google Maps) present in internal ficha templates must be stripped before publishing — ML prohibits off-platform redirection

## Rules from competitor analysis (permanent)
- Include square meters only if present in source data — never prompt for it
- Specify security features with precision (e.g., "cercado eléctrico, portón eléctrico") — always ask if not in the ficha
- Name specific nearby businesses rather than generic proximity language — always ask if not in the ficha
- Preserve the "Beneficios" block from the internal Telegram bot ficha format rather than replacing it with Claude-generated content

## SEO logic
- The ML algorithm weights word order; titles should move from general to specific
- Venezuela-specific keyword validation is done via `tendencias.mercadolibre.com.ve` (web panel only — no API access for Venezuela)
