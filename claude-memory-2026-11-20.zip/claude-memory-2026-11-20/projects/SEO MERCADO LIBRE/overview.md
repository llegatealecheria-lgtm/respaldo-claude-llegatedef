---
name: "overview"
description: "Llégate a Lechería vacation rental brand — purpose, brand voice, personas, differentiators, working style, and current listing work in motion"
---

- Naylu runs Llégate a Lechería, a vacation rental brand based in Lechería, Anzoátegui, Venezuela
- Primary objective: producing optimized, publication-ready Mercado Libre (ML) listing copy for her rental properties, consistent in format, tone, and SEO strategy

## Brand voice & personas
- Brand tone is "like that friend who gets you out of your routine" — warm but not casual to the point of being unprofessional
- Key buyer personas: families, digital nomads, corporate executives, frequent tourists
- Origin markets primarily Caracas, Puerto Ordaz, El Tigre, Maturín, and Anaco

## Key differentiators
- Local host experience
- Guide service
- Starlink/fiber optic connectivity
- Self check-in

## Working style
- Communicates in direct, informal Venezuelan Spanish
- Prefers bullet-format responses
- Wants contradictions or missing data flagged explicitly rather than gaps filled with assumptions

## Current state
- Actively developing and refining a reusable copywriting skill (`mercadolibre-copywriter-seo`) at `/mnt/skills/user/mercadolibre-copywriter-seo/SKILL.md`, encoding full business context, formatting rules, and SEO logic so listings stay consistent across properties
- Active properties worked on: Tepui Caribe and Vientos de Mar (Pequeño)
- Listings drafted for Apto. Doral Beach, with two open items unresolved: property classification (apartment vs. townhouse), and whether tariffs in euros should be converted to USD for ML publication
- Title development depends on keyword research studies not yet documented in the skill — Claude should flag this gap and request those findings rather than improvise titles
