---
name: "llegate-manager"
description: "Llégate Manager — plataforma propia (CRM, disponibilidad, reservas, finanzas) que Naylu está diseñando para Llégate a Lechería"
---

- Está diseñando y desarrollando "Llégate Manager", un sistema propio para [[llegate-a-lecheria]] que integra CRM, disponibilidad centralizada de propiedades, cotizaciones, reservas, finanzas, portal de propietarios e integraciones (WhatsApp, Instagram, TikTok, Google Calendar)
- Stack elegido inicialmente: Lovable + React/TypeScript + Supabase; presupuesto de herramientas de unos USD 50–100 al mes
- Quiere trabajar por fases (análisis → diseño funcional → construcción módulo por módulo → pruebas), sin conectar datos reales ni el WhatsApp operativo hasta aprobar pruebas
