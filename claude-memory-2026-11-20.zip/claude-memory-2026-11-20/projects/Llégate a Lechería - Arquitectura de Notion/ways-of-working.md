---
name: "ways-of-working"
description: "How Naylu wants this Notion work done — approval flow, question pacing, language, and output format"
---

- Naylu expects previews, impact assessments, and clarifying questions before execution — do not proceed unilaterally on decisions
- Nothing should be delivered until it verifiably works
- Prefers one question at a time to avoid information overload
- Prefers direct execution over step-by-step instructions when architecture decisions are already made
- Spanish throughout all interactions
- Output format: bullets, comparative where useful, no filler language
