---
name: "notion-mcp-mechanics"
description: "Hard-won Notion MCP tool behaviors and limits — read before creating views, formulas, or charts"
---

## View creation

- `notion-create-view` with `parent_page_id` appends to the absolute bottom of the page, outside any toggle blocks — repositioning inside toggles requires manual drag-and-drop in the UI
- Views created this way frequently report success silently without actually inserting — the only reliable verification is fetching the parent page and confirming the block's database URL appears in the content structure
- Board views created via API group by "group" mode (macro buckets) by default, not "option" mode (individual values as columns); the existing Pipeline Kanban uses "option" mode correctly, and API-created boards with "group" mode on status fields consistently fail to render
- Formula properties silently ignore `groupBy` parameters — no error is returned, the view just remains ungrouped
- There is no available tool to delete individual views — only entire data sources can be archived via `in_trash`

## Formulas and queries

- `ADD COLUMN FORMULA()` syntax requires chained `or` operators, not the `or(a, b, c)` function syntax — the latter throws a 400 error
- `notion-query-database-view` returns all properties regardless of the `displayProperties` filters defined in the view
- Formula and rollup columns cannot be selected in SQL-style queries — computed values must be inferred from source data

## Plan limits and structural risks

- Notion's free plan counts Chart views cumulatively across creation events, not just currently active ones — creating, deleting, and recreating a chart can still trigger the paywall
- Embedding database views into Dashboard pages via text-based `update_content` is fragile and risks structural corruption of sibling toggle sections
