---
name: "overview"
description: "Notion CRM architecture for Llégate a Lechería, key people, current state, and what's next"
---

## Purpose & scope

- Naylu runs Llégate a Lechería, a vacation rental operation in Venezuela
- Claude acts as a dedicated Notion architect — executing CRM maintenance, schema changes, view creation, and system improvements directly via the Notion connector, not just providing instructions
- Scope extends beyond the CRM to all of Naylu's Notion work, including university projects and other initiatives like Visuarte

## Architecture

- The Notion CRM consists of five interconnected pieces: Clientes, Pipeline Comercial, Reservas, Cartera de Propiedades, and a Dashboard Comercial page
- The Notion CRM is the architecture and source of truth; a separate external decision panel handles dynamic analysis and filtering
- Architecture principle: no redesigns — only integrate changes without breaking existing relations, rollups, or formulas
- Dynamic analysis and filtering are deliberately out of scope for Notion

## Key people

- Angel — colleague who built Jera.IA, an AI agent that integrates with the CRM for property recommendations
- Jera.IA reads property names and field names directly from the CRM, so any schema or naming change must be communicated to Angel proactively, before or immediately after execution
- Schema changes are communicated to Angel via WhatsApp

## Current state (as of import — re-verify before relying on it)

- Global rename of "Oportunidades" → "Recurrencias" executed across all databases, rollups, relations, and CRM manual text
- New Dashboard views added: payment status Kanban (grouped by Estado del pago), property performance table (📊 Rendimiento de Propiedades), city of origin board (🌍 Clientes por Ciudad de Origen), and leads funnel table (🔻 Embudo de Leads)
- "Rango de Edad" formula field added to Clientes with a corresponding table view (grouping by formula confirmed unsupported in Notion)
- "Prioridad Manual" checkbox added to Cartera de Propiedades, surfaced in the main Table view, the Rotación de Propiedades Kanban, and a dedicated audit view (📌 Prioridad Manual)
- Bugs resolved: duplicate "Cliente" relation in Reservas removed (the orphaned field was breaking rollup counts), legacy "CRM — Propiedades" database removed, test records re-linked
- PENDING: prepare a WhatsApp message for Angel about the Oportunidades → Recurrencias rename — it affects Jera.IA if it queries fields or properties by exact name
- Dashboard audit found redundant views: the new Embudo table duplicates the existing Pipeline Kanban; Rendimiento de Propiedades overlaps with two existing property views
- Dashboard audit found missing configurations: the Clientes Kanban and the Rotación de Propiedades board both lack GROUP BY settings (likely predate recent work)
- Dashboard audit flagged three backup views in the Clientes section as cleanup candidates

## On the horizon

- Dashboard cleanup and deduplication of redundant views
- Open developer-facing items for Angel/Jera.IA validation: confirm Jera searches by WhatsApp before creating a new client record; confirm Jera writes to the now-unique "Cliente" field in Reservas
- Multi-channel identifier strategy (Telegram usernames, potential WhatsApp username migration) deferred until formats are confirmed in production
- Chart/visual dashboard section deferred to a later phase — the Notion free plan chart limit was a blocker
- Continuing to use the CRM and the skill for university and other Notion projects

## Tools & resources

- Notion is the primary workspace, with the Notion MCP connector used for direct execution
- Custom Claude skill `arquitecto-de-notion` with three files: `SKILL.md`, `references/mecanica-notion.md`, and `references/sistema-llegate-a-lecheria.md` (frozen architecture reference, loaded only when working on the Llégate a Lechería CRM)
- Claude Project: `Gestión de Notion — Llégate a Lechería`
