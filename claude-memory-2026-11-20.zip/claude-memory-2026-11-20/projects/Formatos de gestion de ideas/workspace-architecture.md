---
name: "workspace-architecture"
description: "Reference for the Tablero de desarrollo database — Kanban stages and task/subtask properties"
---

- Single database: Tablero de desarrollo
- Kanban stages, in order: 💡 Ideas/Por validar → 🧠 En análisis → ✅ Aprobado por Nay → ⚙️ En desarrollo → 🧪 En pruebas → 🚀 Listo/Implementado → ⛔ Bloqueado
- Task properties: Status; Dificultad (Alta/Media/Baja); Prioridad (Urgente/Importante); Etiqueta (multi-select); Fecha de entrega (optional); Versión (text); Depende de (self-relation)
- Subtask properties: Name; Checkbox; optional Date; optional Notes
- The task template page carries seven fixed subtasks
