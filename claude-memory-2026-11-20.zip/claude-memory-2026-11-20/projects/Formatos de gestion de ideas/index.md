---
name: "Formatos de gestion de ideas"
description: "Formatos de gestion de ideas — Building a simple Notion workspace to capture and execute AI development ideas for IA Asesora Comercial."
---

