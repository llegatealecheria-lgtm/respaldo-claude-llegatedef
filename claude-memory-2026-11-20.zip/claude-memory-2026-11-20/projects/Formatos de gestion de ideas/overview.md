---
name: "overview"
description: "Purpose, team, design principles, and current build state of the Notion workspace for the IA Asesora Comercial project"
---

## Purpose & context

- Naylu is building a Notion workspace to manage AI development ideas for a project called "IA Asesora Comercial"
- Core goal: a simple, long-term idea capture and execution system — zero lost ideas, maximum execution, minimal documentation and complexity
- The previous setup was in Asana; the new Notion system should match that level of simplicity

## Team

- Nay — director; approves all decisions based on business objectives
- Jera — manages decisions about AI attention and personality
- Ángel — developer; handles technical execution
- All three share a single company Notion account via one email
- Approval chain: Jera and Ángel operate within their own domains; Nay approves based on business objectives

## Key learnings & principles

- Simplicity over completeness — Naylu explicitly rejected an overly complex first proposal; the benchmark is parity with Asana's straightforward experience
- Execution-first design — the system exists to capture ideas and move them forward, not to document or create overhead
- One database, no sprawl — a single central database with role-filtered views is preferred over multiple databases or documentation pages

## Approach & patterns

- Naylu responds well to structured, question-by-question requirements gathering before any solution is proposed
- Aesthetic preferences are strong: colorful workspace with emojis and a specific brand color palette (palette was shared during the conversation)

## Tools

- Notion (via MCP tools) — primary workspace and project management platform
- Asana — previous tool, now used as the simplicity benchmark

## Current state

- The Notion workspace has been partially built via MCP tools
- Built so far: main workspace page; a single database "Tablero de desarrollo" with Kanban and chart views; three role-specific dashboards (Nay, Jera, Ángel); a task template page with seven fixed subtasks
- Remaining manual step for Naylu: rename Notion's default status values to the seven custom Kanban stages
- Remaining manual step for Naylu: convert the template page into an official Notion template
