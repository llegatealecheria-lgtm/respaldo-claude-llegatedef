---
name: "overview"
description: "Purpose, operating rhythm, and current state of Naylu's weekly planning system across her two business brands"
---

## Purpose & scope

- Naylu is a business owner managing two main areas: a rental/real estate brand called Llégate a Lechería, and a personal brand (Marca Personal)
- Work spans content production, campaign management, client logistics, market analysis, and strategic growth initiatives
- A reusable productivity skill named `planificador-semanal` was created as a SKILL.md file, functioning as an orchestration layer that delegates to her other installed skills (ClickUp manager, Meta Ads, copywriter, market analyst, etc.)
- Naming conventions for skills: kebab-case, Spanish

## Operating rhythm

- Execution week runs Tuesday–Saturday; Saturday is now a full day (8:00am–5:00pm), not morning-only
- Monday is reserved exclusively for the weekly planning ritual — no execution work, and Monday is fully free of university classes
- Workday is 9:00–18:00
- Naylu is enrolled at USM (Núcleo Oriente) in Comunicación Social Corporativo; her class schedule blocks Tuesday/Thursday/Friday afternoons (~12:15pm–5:30pm) and Wednesday from 2:00pm, leaving mornings (and Wednesday's morning until 2pm) free for business deep work
- Monthly/weekly planning is anchored to 3 root business objectives (replacing an earlier 4-week rotating cycle draft): (1) facturar 2K en temporada baja — driven by content posting frequency, ads, sales channel amplification, the corporate catalog, and the new boletería line; (2) fortalecer relación comercial con propietarios — driven by corporate-rate negotiation meetings with each catalog property owner; (3) alianzas comerciales (transportes y comidas) — currently maintenance-only, 2 gastronomic alliances already closed, transporte pursued opportunistically rather than actively
- Daily priority structure is the "Big 3" — three priority tasks per day
- Weekly anchor is one "aguja estratégica" (strategic needle) per week
- Energy map: deep creative/strategic work in mornings (🌅); administrative and reactive tasks in afternoons (🌇)
- Batching principle: group similar task types to avoid attention fragmentation
- Naylu has a video editor who supports her with content editing for Llégate a Lechería
- Monday afternoons are reserved for financial cuts to pay [[jera-larez]] her commission

## Current state

- Business objectives exist partially in ClickUp but need refinement; the skill's workflow treats this as a preliminary step before weekly task distribution
- A concrete weekly plan was built from a real task list covering: content production, September campaign preparation, client logistics, an institutional letter to city hall, market analysis, and strategic growth items (diversifying Llégate, a business alliance, relaunching Mercado Libre, researching a reviews platform)
- ClickUp task creation is in progress: one task created — "Trazar metas para diversificar Llégate" in Tablero de Tareas
- Remaining tasks are pending Naylu's confirmation before sequential creation proceeds
- Q4 2026 priority for Llégate a Lechería is Expansión de cuentas (comunicación diferenciada corporativo/turístico, aptos mgta, alianza comercial, relanzamiento de Mercado Libre), ranked above the recurring content line and above fidelización/reconocimiento
- Alianza comercial and the Mercado Libre relaunch remain active goals
- Naylu doesn't update ClickUp daily, so it lags behind her actual pending items — real status has to be pulled from her verbally/notes, not assumed current from ClickUp alone
- Corporate catalog (catálogo corporativo) is blocked on scheduling meetings with candidate properties Joanna, Isidra, Ana Elis, and Marina Mar/Ana to negotiate corporate pricing and get photos; still needs price tiers for 3/7/10+ nights and a web form + auto-quoter for corporate clients
- Property owner Yuliditza is a candidate for the corporate catalog but the relationship has had prior friction that needs repairing
- Sales advisor [[jera-larez]] has delegated follow-up items (MercadoLibre results, marketplace property publication, Notion/Drive format organization) that Naylu checks in on weekly, starting Saturdays
- New revenue line launching: boletería de avión, starting with training courses on Saturdays
