---
name: "Organizador semanal"
description: "Organizador semanal — Weekly planning system and ClickUp workflow for Naylu's two business brands."
---

