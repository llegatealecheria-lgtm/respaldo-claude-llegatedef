---
name: "tools-and-conventions"
description: "ClickUp structure, task-creation conventions, and the tool suite backing the weekly planning workflow"
---

## ClickUp structure

- ClickUp is the primary task and project management tool
- Space "Llégate a Lechería" → Lists: `Tablero de Tareas` (ID: `901417784409`) for general weekly tasks; `Objetivos` for goal tracking
- Space "Marca Personal" → List: `General`
- General pending tasks go in `Tablero de Tareas` — not in Objetivos or Marca Personal
- Optional custom field `Objetivo relacionado` becomes useful once objectives are finalized

## Task-creation conventions

- Task creation uses the fields: `list_id`, `name`, `due_date`, `priority`, `markdown_description`
- The `markdown_description` field encodes the energy block (🌅/🌇) and the associated business objective, since ClickUp has no dedicated time-of-day field
- ClickUp requires re-approval for each write action after the first in a session, so bulk task creation should always present the full task list first for a single user confirmation, then execute sequential calls

## Other tools

- Meta Ads for campaign management (skill installed)
- Mercado Libre as a sales channel; a relaunch is in progress
- Installed skill suite includes: ClickUp manager, Meta Ads, copywriter, market analyst, and others
