---
name: glosario-formatos-marca
description: Proyecto de Naylu: índice o glosario de formatos en uso de la marca, en Notion, con pasos, copys y skills para que cualquiera ejecute el proceso
aliases: [índice de formatos, glosario de formatos]
---

- Está armando un índice/glosario de formatos en uso por la marca; ya tiene un cuerpo base en Notion y quiere añadirle pasos, copys, skills, etc. para que el proceso se pueda ejecutar independientemente de quién lo haga
- Quiere ir construyéndolo por partes y que se le pregunte ante cualquier duda antes de elaborar algo
- Se llama "Formato LAL" (en Notion: "Formatos of LAL" con la base "Glosario de formatos"); solo cubre Llégate a Lechería
- "Formatos" = todo lo que han diseñado: sheets, Notion, inventario, forms, etc.; el ejecutor puede ser la CEO, la asesora de ventas, etc.
- Nivel de detalle: proceso complicado (ej. configurar artifacts) → paso a paso; algo sencillo → solo links, instrucciones mínimas, skill a usar e info de interés
- No va en su planificación semanal; es para centralizar la información de procesos
- Los formatos se irán agregando al glosario a medida que se revisan; los 5 actuales y los tags existentes se mantienen
- Aprobó que los pasos, skills y copys vivan dentro de cada página del formato (no como propiedades de la base), con plantilla por nivel Sencillo/Complejo y tags nuevos por app (Sheets, Notion, Forms, Artifacts) y por área (Ventas, Operaciones)
- El "Cotizador de paquetes" es un artifact creado en Claude para Blessing Travels; será el primer formato de ejemplo
- El Cotizador de paquetes vive en un artifact (su link es donde vive); para reusarlo con otro aliado se le pide a Claude cambiar tarifas y propiedades. Sin skill ni copys asociados (no aplica). Lo usan la CEO y la asesora de ventas
- Decidió reducir el cotizador a las láminas 5 en adelante, con textos generales para cualquier aliado; el link base reemplaza al anterior y funciona como "formato 0" intacto: se hace una copia por cada aliado
- Ya quedó escrita en Notion la página de ejemplo del Cotizador y aplicados los tags nuevos; los otros formatos se irán completando de a uno con la misma plantilla
- Sumó un nivel "Intermedio" a la plantilla (además de Sencillo y Complejo); los otros 4 formatos viven en Google Sheets (Bases de datos también en Forms): Ingresos LAL e Inventario maestro = Intermedio; Bases de datos y Produccion LAL = Complejo; Inventario maestro y Produccion LAL los usa también el desarrollador (Produccion se edita mediante él); en ninguno aplica skill, se llenan a mano
FINAL WRITE
- Ya están escritas las 4 páginas restantes en Notion (los 5 formatos completos). Bases de datos y Produccion LAL están automatizados, por eso sin paso a paso (Produccion se edita vía desarrollador); Ingresos LAL e Inventario maestro se llenan a mano. En Inventario maestro la información debe verificarse antes de ingresarla. Definición de Produccion LAL cambiada a "Resumen ejecutivo y seguimiento financiero de reservas y comisiones". El link del Form de Bases de datos se agrega después
FINAL WRITE
- Añadido al glosario el formato "Cortes administrativos" (skill /corte-administrativo-llegate), nivel Complejo, tags Finanzas de la empresa y Ventas, se entrega en el chat; ya son 6 formatos
