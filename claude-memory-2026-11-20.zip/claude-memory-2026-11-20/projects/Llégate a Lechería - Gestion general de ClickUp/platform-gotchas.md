---
name: "platform-gotchas"
description: "Hard-won ClickUp/Asana API and tooling constraints, member IDs, and verification techniques — read before automating or assigning tasks"
---

## Member IDs

- Jera's correct ClickUp member ID is `222059093` (Jera Larez, jeralarez.05@gmail.com — with dot)
- ID `101260135` (jeralarez05@gmail.com, no dot) is a wrongly created pending invite and must never be used for task assignment
- The bad invite requires manual cancellation in ClickUp workspace settings — it is not removable via API

## API and platform constraints

- Recurring task configuration and automation creation cannot be done via ClickUp API — both require manual setup in the app
- ClickUp's `clickup_update_task` with `assignees: ['new_id']` replaces the full assignee array, so no separate remove step is needed for corrections
- Asana subtask fields (`completed`, `assignee`, `due_on`) are not reliably returned by `get_task` with `opt_fields` — each subtask must be fetched individually by GID

## Verification techniques

- Tag existence in a Space must be verified via a round-trip `add → remove` test on a known task ID — `filter_tasks` returning empty results does not confirm tag absence
- Never infer the platform (ClickUp vs. Asana) from task name content — verify against UI structure or API responses only
- Tasks in "🚀 Listo / Implementado" appearing hidden is ClickUp view behavior, not missing data — enable "Show closed tasks" and expand parent toggles to resolve

## Skill packaging

- Skill names must be lowercase with hyphens only for packaging (e.g. `clickup-gestor-de-proyectos`); display titles inside `SKILL.md` can use mixed case freely
- Packaging workflow: run `python -m scripts.package_skill [skill-name]` from `/home/claude`, copy the `.skill` to `/mnt/user-data/outputs/`, then `present_files` to generate the Save skill card
- If the `.skill` file already exists in outputs, `present_files` can re-present without repackaging
