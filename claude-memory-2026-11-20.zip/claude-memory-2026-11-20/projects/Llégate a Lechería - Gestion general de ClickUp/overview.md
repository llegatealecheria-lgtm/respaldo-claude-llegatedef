---
name: "overview"
description: "Purpose, team roles, workspace setup, and current state of the ClickUp/Asana project management work — read first"
---

## Purpose & context

- Naylu works with a small team on AI-related projects
- Three defined roles: Jera handles project management and coordination, Angel handles technical/AI development, Naylu handles validation and approvals
- Primary workspace is ClickUp — Space "Espacio del equipo [ES-LA]", Space ID `90176234270`
- Asana is also active and used as a reference model for structure and workflows
- Ongoing initiative: building and maintaining ClickUp project management skills (`.skill` files) that mirror validated Asana patterns rather than starting from scratch

## Current state

- Migration of "IA Atención Clientes" from Asana to ClickUp is 100% complete and verified — tasks, subtasks, dependencies, assignees, statuses, dates, descriptions, and list names with emojis all match Asana; no pending items remain
- The `clickup-gestor-de-proyectos` skill has been built, packaged, and delivered, covering the full project lifecycle in ClickUp: workspace mapping, project creation, reorganization, task management, filtering, automation recommendations as manual steps, and status reports
- The skill replicates Naylu's 9-list structure: 💡 Ideas → 🧠 Gestión → ✅ Validación → ⚙️ Desarrollo → 🧪 Pruebas → 🚀 Implementado, plus three personal task lists (one per team member)
- Open item: project instructions for this skill referenced the old filename `gestor-de-proyectos-clickup.skill` instead of the corrected `clickup-gestor-de-proyectos.skill` — worth verifying/updating
- Difficulty-level tags exist in the workspace: `prioridad baja` (completable in a few hours), `prioridad media` (3+ days, less than a week), `prioridad alta` (weeks or months)

## Tools & resources

- ClickUp MCP is the primary project management platform
- Asana MCP is the secondary platform, used as structural reference; reliable call is `get_project` with `include_sections: True` for full section retrieval in one call
- Active skills: `clickup-gestor-de-proyectos` (ClickUp lifecycle management) and `gestor-de-proyectos-asana` (reference model)
- Brand palette (Pantone): `#F2E5B3` / 7499C (crema) and `#FFC66E` / 1355C (amarillo-naranja cálido) — background use only
- Brand palette (Pantone): `#65BBB0` / 563C (verde-azulado) and `#00607F` / 7707C (teal oscuro) — text, icons, and shadows only; never as background or card fills
