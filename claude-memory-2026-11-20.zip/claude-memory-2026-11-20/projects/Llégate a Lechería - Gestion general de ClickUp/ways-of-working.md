---
name: "ways-of-working"
description: "Collaboration and communication patterns for this project — how to propose, confirm, and report"
---

- Maximum 1–2 clarifying questions before proposing a full structure
- No filler language; bullet-point format
- Confirmation required before team-visible bulk actions; direct execution for explicit one-off requests
- Recommendations kept strictly separate from objective status reports
- Design principles already validated are not reopened unless Naylu prompts it
- New ClickUp structures mirror validated Asana structures rather than being built from generic templates
