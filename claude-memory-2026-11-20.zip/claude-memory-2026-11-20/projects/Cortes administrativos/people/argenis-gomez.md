---
name: "argenis-gomez"
description: "Argenis Gomez — propietario de Llégate a Lechería con unidades en Marina del Rey y Costa Guaica"
---

- Propietario que trabaja con [[llegate-a-lecheria]]; solo tiene Marina del Rey y Costa Guaica, no tiene Thai
