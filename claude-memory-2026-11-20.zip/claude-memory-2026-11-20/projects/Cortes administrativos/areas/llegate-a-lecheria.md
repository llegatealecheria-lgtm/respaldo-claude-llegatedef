---
name: "llegate-a-lecheria"
description: "Llégate a Lechería — corte semanal y modelo maestro comparativo (años/meses), formato PDF o interactivo"
---

- El objetivo final de los cortes es un "modelo maestro" que permita comparar data vieja y nueva por años o meses específicos; el formato será PDF o interactivo según lo amerite la reunión
- El corte semanal de los lunes se mantiene igual, con un cuadro añadido de % de ventas y su ganancia; el modelo maestro debe filtrar por semana, trimestre, semestre y año sin perder las métricas de 2025
- Paleta de marca: teal Pantone 563C (#65BBB0), dorado Pantone 1355C, crema Pantone 7499C (#F2E5B3), navy Pantone 7707C (#00607F)
- La comisión de ventas en los cortes se calcula como 20% de la ganancia Llégate de cada reserva (no del monto total)
- Los cortes se titulan "Corte Administrativo" con el periodo como subtítulo (semanal, mensual, comparativo…), sin el nombre del último cliente en el encabezado; deben incluir las métricas que ya vienen manejando: ingresos, propiedades y conjuntos más alquilados, y ranking de propietarios con cuánto se les generó
- El periodo del corte semanal es de lunes a lunes, delimitado por el último cliente registrado (arranca después del último cliente del corte anterior)
- Pedido de gerencia (oct 2026): resumen ejecutivo más visual (se entiende por los ojos antes que leyendo); reemplazar "Facturado" por "Por cobrar" y priorizar lo generado por Llégate sobre montos completos; la semana del corte debe verse siempre (no negociable); el comparativo debe mostrar el monto generado del corte pasado vs el presente (VS)
- Gerencia quiere un diferencial marcado entre el bruto de Llégate y el bruto generado para los propietarios en los cortes; se decidió incluir las conversaciones de WhatsApp también en el corte comparativo (oct 2026)
- El propietario Argenis Gomez solo tiene Marina del Rey y Costa Guaica (no tiene Thai)
- El corte comparativo debe cerrar con una hoja adicional de análisis de métricas redactada por Claude: consejos, detalles a mejorar y puntos fuertes de la temporada (oct 2026)
- En los cortes, todo número alerta o umbral que proponga Claude debe llevar siempre una leyenda que indique que es un número alerta y no sale de las cifras del corte
- Quiere agregar la inversión en ADS (facturación de Meta) a ambos cortes, semanal y comparativo, y que la sección de notas sea más digerible y sirva de apoyo para tomar decisiones (oct 2026)
- Criterio de mes en los cortes: el dinero de una reserva cuenta en el mes en que se paga la reserva, aunque la estadía sea en otro mes (ej. diciembre); las reservas anticipadas cuentan igual en ambos años (oct 2026)
- Aprobó las notas de los cortes por bloques (Decidir / Corregir en Sheets / Para leer bien el corte) y pidió que lleven siempre su leyenda, igual que la leyenda de porcentajes; si no hay dato (ej. ADS), no se inventa: queda pendiente (oct 2026)
- En el comparativo debe ir una leyenda que explique qué es "Sin registro" (de propietario o canal) para que gerencia no se alarme (oct 2026)
- Las métricas de ADS (ej. ADS por reserva) deben compararse solo contra los clientes cerrados por Meta, no contra todas las reservas (nov 2026)
- Quiere automatizar el corte semanal para que se haga solo cada lunes y ella solo se encargue de enviarlo por los canales pertinentes; antes de actualizar la skill quiere que se le diga qué cambiar (nov 2026)
