---
name: "cierre-anual-2026"
description: "Proyecto madre de Naylu para el cierre de todo lo realizado en 2026, alimentado con resúmenes de sus otros proyectos"
---

- Está armando un "proyecto madre" donde hará el cierre de todo lo realizado en el año, cargando ahí resúmenes de sus otros proyectos (incluido "Gestión con propietarios")
