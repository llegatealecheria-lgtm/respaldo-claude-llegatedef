---
name: "llegate-a-lecheria"
description: "Decisiones de Llégate a Lechería tomadas en el proyecto Gestión con propietarios — anfitrionaje, relación con propietarios"
---

- El anfitrionaje se presenta a los propietarios como parte obligatoria del servicio (no opcional), pagado por el propietario: tarifa estándar por reserva escalonada por noches (10 € para 1–2 noches, 15 € para 3+ noches), solo check-in; además el huésped paga 6 € fijos por reserva, incluidos en la cotización (el check-out queda a cargo del propietario); es la única tarifa que Llégate cobra a propietarios además de su comisión. Naylu quiere que todos lo usen porque da más presencia de marca
- Evaluando escalonar la tarifa de anfitrionaje por noches (6 € para hospedajes de dos noches, 10 € a partir de 3 noches) y que el huésped pague otros 6 € por reserva; aún sin decidir
