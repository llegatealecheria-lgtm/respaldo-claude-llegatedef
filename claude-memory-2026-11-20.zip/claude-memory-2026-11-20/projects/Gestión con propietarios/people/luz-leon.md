---
name: "luz-leon"
description: "Luz León, propietaria de un apartamento en el Conjunto Residencial Las Palmeras (Lechería) en la cartera de Llégate"
---

- Propietaria de un apartamento en el Conjunto Residencial Las Palmeras, Lechería, que trabaja con [[llegate-a-lecheria]]
- Naylu le está pidiendo bajar su tarifa de propietaria de 55 € a 40 € por noche para que el precio publicado (con comisión) quede en 55–60 €; le ofrece anfitrionaje (solo check-in) a tarifa preferencial de 10 € por reserva
