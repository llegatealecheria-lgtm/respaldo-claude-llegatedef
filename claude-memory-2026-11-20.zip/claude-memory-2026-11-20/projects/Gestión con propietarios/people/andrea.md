---
name: "andrea"
description: "Andrea, anfitriona designada de Llégate a Lechería para el servicio de anfitrionaje (check-in) a propietarios"
---

- Andrea es la anfitriona designada para el servicio de anfitrionaje de [[llegate-a-lecheria]]: hace el check-in y entrega a los huéspedes el documento para firmar; Naylu le paga por reserva
