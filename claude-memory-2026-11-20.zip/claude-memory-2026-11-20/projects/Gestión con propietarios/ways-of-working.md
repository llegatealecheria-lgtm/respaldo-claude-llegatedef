---
name: "ways-of-working"
description: "Working principles, communication style, deliverable conventions, and the technical toolchain for Llégate deliverables"
---

## Principles

- Never invent data — consult before assuming; never fabricate figures, owner names, or amenities. All "lo que ya funciona" sections must be built exclusively from photo-verifiable details.
- Framing matters in owner communication: issues should be framed as improvements that protect or maintain portfolio standing, not as disqualifying problems. Concrete example: shifting from "mold" to "humidity stains" in the Bahía Redonda report.
- Property reports should frame issues as improvements needed to maintain portfolio standards, not as barriers to publication.

## Communication style

- Preferred writing style for business communications (especially conflict or negotiation contexts): strategically structured, emotionally intelligent, and orator-level persuasive — assertive without lowering professionalism, anchored in documented facts, and never conceding narrative framing unnecessarily.
- WhatsApp-casual but strategically structured messaging for owner/partner communication; formal professional style for contracts and proposals.

## Workflow patterns

- Activates custom Claude skills (`/consultor-calidad-propiedades-llegate`, `/director`) for recurring workflows, with established personas and rules per skill.
- Iterates on deliverables through mid-course corrections — reviews outputs carefully and flags inconsistencies, math errors, or tone issues proactively.

## Brand

- Llégate brand palette applied consistently across all deliverables: teal `#65BBB0`, navy `#00607F`, gold `#FFC66E`, cream `#F2E5B3`, Poppins font.

## Tools & technical notes

- PDF generation: `wkhtmltopdf` with flags `--enable-local-file-access --page-size Letter --margin-top 0 --margin-bottom 0 --margin-left 0 --margin-right 0`; images embedded as base64 data URIs for self-contained files.
- Image handling: HEIC files require `pillow-heif` registered via `pillow_heif.register_heif_opener()` before PIL can open them; portrait images need explicit `max-height` constraints (e.g. `max-height:300px`) to prevent PDF page bloat.
- PDF layout fixes: caption collisions in multi-photo rows resolved via `max-width: 170px` on `.figcaption` with `margin: auto` and `gap: 28px` on `.figrow`; single-photo figures use `max-width: 300px`.
- Excel data: `Ingresos_Llegate_10.xlsx` processed with `openpyxl`; header row detection requires scanning rows 1–5 for `"propiedad"` (case-insensitive); property name matching requires broad substring patterns (`"guaica"`, `"tepu"`); early sheets (Aug–Sep 2024) record commission-per-night rather than full nightly rate.
- Presentation tools: PowerPoint (16:9) and Word (.docx) with Cambria/Calibri fonts for formal documents.
