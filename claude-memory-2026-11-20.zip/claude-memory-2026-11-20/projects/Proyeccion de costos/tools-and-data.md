---
name: "tools-and-data"
description: "Tools, data sources, file locations, and data-handling gotchas for the Llégate commission model work."
---

- Google Drive holds the master inventory, retrieved as a CSV export (base64-encoded retrieval).
- Google Drive file ID for the inventory: 1YDvUhkQu63wJuGdxN1C-75ZzXStdcAGA2bh2qf9AL0w
- Python/pandas is used for data processing.
- The inventory CSV uses European locale formatting (e.g. `"45,00 €"`), which requires custom parsing beyond standard `pd.read_csv`.
- Excel (`.xlsx`) is the format for the commission model; recalc script at `/mnt/skills/public/xlsx/scripts/recalc.py`.
- Chart.js is used for interactive graphs in HTML deliverables.
- Internal inventory reference: `/areas/llegate-a-lecheria.md`.
- Skill reference: `/mnt/skills/user/analista-de-mercado-llegate/`.
