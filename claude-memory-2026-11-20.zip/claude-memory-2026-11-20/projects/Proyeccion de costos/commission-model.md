---
name: "commission-model"
description: "Llégate a Lechería intermediary commission and pricing model — structure, rules, tiers, pilot status, and owner contacts. Current state as of this import."
---

## Purpose & context
- Naylu works as an intermediary property manager for Llégate a Lechería, handling short-term rentals on behalf of property owners in Lechería, Venezuela.
- Llégate acts as the middleman, not the property owner, and earns a fixed net commission per night in euros (not percentage-based).
- Core business goal: structure pricing and commissions so the model is attractive to both property owners and to Llégate as a sustainable intermediary operation.
- Portfolio spans 36 properties.

## Owner contacts and properties
- Andreina Kovavic — Solmar (active pilot property).
- Francisco — Vientos del Mar.
- David — Guaica Suites.
- Isidra — Guaicamar / Balbina.
- Balbina — Guaicamar Torre B N21.

## Current state — the redesigned model
- Naylu recently redesigned Llégate's commission and pricing model, moving away from a flat structure.
- Rule 1 — Duration-discount curve applied to the owner's cost: 100% for 1 night down to ~58% for 1 month.
- Rule 2 — Fixed €8 management fee per reservation, regardless of stay duration.
- Rule 3 — Tiered nightly commission by property capacity, with two seasonal bands: Baja (which absorbs Media) and Alta.
- Rule 4 — Cleaning pass-through applies only for stays up to 4 nights; cleaning fees go directly to cleaners and are not Llégate income.
- Tier commissions range from €15–18 (up to 4 pax) to €25–30 (11–12 pax), depending on season.
- Cross-season reservations are charged at the commission rate of the starting season.
- The Workation/Corporate Stay segment is excluded from seasonal variation and is always billed at the base tier rate.

## Current state — deliverables
- Three-tab Excel file (Parámetros, Cartera, Cálculo) covering all 36 portfolio properties across duration tiers and both seasons — fully formula-driven and auto-recalculating.
- Interactive HTML presentation in Llégate's brand colors (navy, teal, gold, cream) with scroll animations and Chart.js graphs, covering the rationale, the four new rules, and projected results for three pilot properties over August–December.

## On the horizon
- Validate and potentially roll out the new commission model beyond the three pilot properties (Vientos del Mar, Guaica Suites, Guaicamar) to the broader 36-property portfolio.
- Present the model to property owners using the HTML presentation.

## Key learnings & principles
- Llégate's commissions are fixed euro amounts, not percentages — this distinction is fundamental to all model design.
- Naylu prefers to validate concepts with concrete number examples before committing to structural or design decisions.
- Simplicity is valued: the seasonal tier was deliberately collapsed from three bands to two to reduce complexity in cross-season booking calculations.
- All financial outputs should use euros, not dollars.

## Approach & patterns
- Iterative, example-driven design process: concepts are tested with real numbers before being finalized.
- The model is built to be parametric and auto-recalculating, so any input change propagates across all outputs without manual rework.
- Pilot testing uses real portfolio properties and realistic occupancy projections rather than hypothetical examples.
