---
name: "reporte-forms-clientela"
description: "Reporte interactivo (artifact publicado) de Llégate a Lechería desde el Forms de clientela — no reemplaza al dashboard de Notion, es para reportes puntuales"
---

## Propósito y alcance
- Reporte a partir del Sheet de respuestas de un Forms de clientela; archivo fuente "_Base_de_datos_llegate_2026__Responses_.xlsx" (hoja "Form Responses 1", ~201-202 filas)
- NO reemplaza al dashboard de Notion (crm-dashboard.jsx) — es para reportes puntuales
- Sin conexión en vivo: se regenera manualmente cada vez que Naylu comparte una versión actualizada del Sheet
- Artifact publicado: https://claude.ai/artifact/GMm3nnzhdXiEvZumSjs2BH — a diferencia del dashboard de Notion, este sí persiste entre sesiones (releer/actualizar con la herramienta Artifact en vez de pedir que resuba el archivo)

## Filtro de período
- Basado en "Fecha de ingreso" (check-in), no en el Timestamp de respuesta del formulario
- Quiere poder elegir instancias específicas en todas las granularidades (Día/Semana/Mes/Trimestre/Semestre/Año), no solo el período relativo actual
- Cobertura de datos del snapshot actual: ene-sep 2026 (Q1, Q2 y Q3 parcial)

## Limpieza y normalización de datos
- Motivo de viaje: variantes de "vacacional/vacaciones/vacacionar/etc." se agrupan en "Vacacional"; el caso "15 años" (cliente Jennifer Sulbaran, grupo de 16) se reclasifica como "Cumpleaños"
- Rango de edad: mantiene el esquema del dashboard de Notion (20-25/26-35/36-45/46-55), último rango ampliado a "60+"; rangos declarados en el Forms (ej. "25-30 años") se ubican por punto medio; edades no plausibles (umbral <15) se excluyen como "Sin dato"
- Ciudad: variantes de "no se obtuvo ciudad/ubicación" se agrupan como "Sin dato"
- Canal: variantes de "Referido por cliente X" se agrupan en "Referido"
- "Cantidad de personas": cuando el texto menciona mascota (ej. "4 y 1 perrita") se extrae el número de personas y se marca aparte en una mini-métrica de grupos con mascota
- Columnas descartadas por bajo llenado: "Nombre de evento" (1%) e "Identificador de propiedad" (0%). "ID de propiedad alquilada" queda fuera por ahora (pendiente de pulir). "Cantidad de noches" sí se incluye pese al llenado parcial (~35%), con nota aclaratoria visible

## Propietarios (ranking de unidad más alquilada)
- El ranking se agrupa por "Conjunto — Propietario", no solo por conjunto, porque un mismo conjunto puede tener varias unidades de distintos dueños
- Fusiones confirmadas: "Alexis"/"Alexis Marques"/"Alexis Marquez"/"Alexis Márquez" → Alexis Márquez (Thai); "Joanna"/"Joanna Salazar" → Joanna Salazar (Plaza Guaica); "Virginia"/"Virginia (Playa Mar)" → Virginia (Playa Mar); "Andreina Kovacic"/"Andreina Kovavic" → Andreina Kovacic (Solmar, typo)
- "Alejandro" sin apellido (propiedad "Yate o Lancha") es Alejandro Rodríguez, el capitán; las propiedades "Yate"/"Lancha"/"Yate o Lancha" se unificaron en una sola porque es el mismo bote
- "Ashly Contreas o Andrea Rinaldi" se deja como propietario conjunto tal cual, sin dividir
- "Alquila en lecheria" es un aliado comercial (no un propietario), se deja tal cual

## Identidad visual
- Misma paleta e identidad del dashboard de Notion; dorado en #FFC66E; bordes de tarjeta más marcados que en el dashboard de Notion para dar sensación de mayor interactividad
- Logo: de las dos versiones que compartió Naylu, se usó la del aro blanco (piensa mejor en fondos de color)

## Métricas del reporte
- Motivo de viaje con chip de "más frecuente" / "menos frecuente"
- Rango de edad, tipo de cliente, ciudad de origen y canal de captación, filtrables por el período
- Tamaño de grupo: KPI aproximado (promedio) + gráfica de distribución por rangos (1-2/3-4/5-6/7-8/9-12/13+)
- Mini-métrica de grupos con mascota
- Unidad más alquilada por cantidad de reservas (Conjunto — Propietario)
- Resumen del período: texto dinámico con lectura de tendencias y puntos de mejora (sin modelo de forecasting real, son observaciones sobre los datos filtrados)

## Interactividad
- Tooltips al pasar el mouse sobre cualquier barra o segmento
- Motivo de viaje, Unidad (Conjunto—Propietario) y Tipo de cliente son clicleables: filtran todo el reporte, con un chip para quitar el filtro
- KPIs animan al cargar; transición suave al cambiar de período
- Pidió "algo interactivo que invite a seguir viendo y no sea forzado de ver", dejando el criterio específico a Claude

## Aprendizajes técnicos
- No usar librerías de gráficos externas vía CDN — Chart.js desde cdnjs falló al cargar en el artifact publicado (los KPIs se veían pero las gráficas y el resumen no, porque el error al fallar `Chart` interrumpía el resto del render). Las gráficas se generan como SVG inline hecho a mano, sin dependencias externas
- El logo debe extraerse siempre de forma programática (recorte + base64 vía Python) cuando Naylu suba el archivo de imagen — nunca transcribir un base64 largo a mano desde el chat
