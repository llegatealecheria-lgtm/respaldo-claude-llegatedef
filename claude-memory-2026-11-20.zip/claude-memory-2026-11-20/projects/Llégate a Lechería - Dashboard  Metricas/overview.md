---
name: "overview"
description: "Llégate a Lechería CRM dashboard — purpose, brand identity, Notion data sources, and current dashboard state"
---

## Purpose & context

- Naylu manages Llégate a Lechería, a vacation rental CRM centered on properties in Lechería, Venezuela
- Primary project is a live, interactive CRM dashboard (React/JSX) pulling data from four Notion databases, rendering business KPIs, funnel charts, and property performance visualizations
- The dashboard serves as a managerial control panel for the rental operation

## Brand palette (exact, confirmed)

- Teal (dominant): Pantone 563C → `#6BBBAE`
- Cream (dominant): Pantone 7499C → `#F1E6B2`
- Gold/mustard accent: Pantone 1355C → `#FFC66E` (not #C9A24B or #FFC56E — both prior guesses were wrong)
- Navy/blue accent: Pantone 7707C → `#00617F`

## Dashboard identity

- Header h1: "Dashboard Llégate a Lechería"
- Small label above h1: "Panel Gerencial" (avoids repeating "Dashboard")
- Logo: Naylu's original circular brand mark (sun + waves + wordmark), embedded as a base64 PNG data URI with white-pixel background removed
- Never recreate or redesign the logo as SVG — always use the original artwork

## Data sources (Notion DB IDs)

- Clientes: `1fa608e7-2324-4d0e-8ce5-d6badd1cda45`
- Pipeline Comercial: `fdf17c5c-615c-4dab-80e8-b0d73ac58cff`
- Reservas: `98108515-533c-458c-b2e0-3dbe27d272fd`
- Cartera de Propiedades: `367eb89c-87eb-8018-beee-000b92fb67a0`
- Dashboard Comercial page: `379eb89c-87eb-80cf-8333-d8ae177eb420`

## Fields fetched per database

- Clientes: Edad, Ciudad de origen, Fecha primer contacto
- Pipeline: Motivo de viaje, N.º de huéspedes, Propiedad de interés (relation), Escalado a humano, Motivo de escalamiento
- Propiedades: Target, VIP

## Current state — active dashboard views/cards

- `crm-dashboard.jsx` is a working React artifact using Recharts for visualizations, connected live to Notion via the Anthropic API's MCP server
- KPI cards including "Total de Leads" and "Recurrencias activas" (renamed from "Oportunidades activas")
- Funnel chart, donut charts, bar charts, revenue line chart
- "Rendimiento de Propiedades": Recharts line chart with three separate lines — Enviadas, Reservadas, Recurrencias — plus a local property size filter (Pequeña/Mediana/Grande) scoped only to that chart section, not the global header
- Casos Escalados a Humano (full breakdown by motivo)
- Motivo de viaje
- Tamaño promedio de grupo — avg N.º de huéspedes across all pipeline entries with the field filled in the period, both consulted and reserved; not about which property rents most
- Clientes por Ciudad de Origen
- Clientes por Rango de Edad, custom buckets: 18-25 / 26-35 / 36-45 / 46-55 / 56+
- Reservas del período por segmento (Target) + ingresos de propiedades VIP — replaced static "Composición de cartera"
- Age filter buckets in the filter UI start at 20-25 and end at 60-65

## Current state — global period filter

- Pill-shaped, in header: Todo / Día / Semana / Mes / Trimestre / Semestre / Año, default "Todo"
- Filters by: Clientes → "Fecha primer contacto"; Pipeline → "Fecha creación"; Reservas → "Fecha reserva"
- Deliberately not period-filtered (always all-time or forward-looking): seguimientos vencidos, próximos check-ins, property "Nivel de rotación"

## Current state — visual style

- Aesthetic: airy, rounded, minimalist sidebar, blob decorative accents, alternating teal-pale/cream-pale section backgrounds
- Large border radii: cards ~28px, sections ~40px
- Gradient pill-shaped bar charts across chart sections; rounder KPI icon badges
- "Rendimiento de Propiedades" gradient fills: teal-pale = Enviadas, gold = Reservas, navy = Recurrencias

## Current state — refresh and caching

- No visible "Actualizar datos" button — intentionally hidden by design
- The ✨ sparkle icon at the top of the sidebar nav rail silently triggers a Notion data refresh, with only a subtle hover animation as a hint
- `window.storage` (personal, not shared) caches the last successful Notion pull so the dashboard paints instantly on open, then silently re-syncs live data in the background — user-approved

## On the horizon

- Considering deploying the dashboard to Vercel (already connected to her account) for a permanent standalone URL independent of the Claude chat — offered but not yet confirmed or executed
- `crm-dashboard.jsx` does not auto-persist between conversations; Naylu must re-upload the current file each session to enable further edits
