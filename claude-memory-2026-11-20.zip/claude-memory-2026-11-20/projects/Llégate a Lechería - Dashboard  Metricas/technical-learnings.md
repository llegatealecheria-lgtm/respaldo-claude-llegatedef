---
name: "technical-learnings"
description: "Hard-won Notion MCP, API, and field-naming rules for the CRM dashboard — read before touching data fetching"
---

## API and MCP constraints

- `max_tokens` must be 8192 for Notion queries now that more fields per row are fetched across all four databases (previously 4096; 1000 caused silent mid-JSON truncation failures)
- Concurrency limit: four simultaneous Anthropic API fetch calls hits an `exceeded_limit` error (`representativeClaim: "concurrents"`). Working pattern is pairs of 2 concurrent calls via `Promise.all` — never 4 at once, never fully sequential
- Retry logic: on `exceeded_limit` or HTTP 429, retry up to 3 times with increasing backoff (`attempt × 1200ms`)
- Always extract and display the actual `error.message` from the API response body in the UI — generic fallback messages make debugging impossible
- Notion MCP prompts must explicitly instruct output as minified JSON array only — no markdown, no code fences, no prose — or the JSON parser breaks
- Notion view queries: fetch view-level filter/sort configs via `notion-fetch` on individual view URLs, `https://app.notion.so/p/[view-id]`

## Field naming (critical — bugs occurred with old names)

- The relation field is "Recurrencias" (Clientes) / "Recurrencias asociadas" (Propiedades) — NOT "Oportunidades"
- JSON key is `totalRecurrencias`
- The "Total Enviadas" rollup is never fetched (rollup-of-formula, unreliable via MCP); "enviadas" is recomputed client-side by counting Pipeline entries per property where Etapa has reached "Opciones Enviadas" or later
- Rollup-of-formula fields are unreliable via MCP generally — never fetch them; always recompute client-side from raw relation data
- Property size (Pequeño/Mediano/Grande) is parsed client-side from the property title string pattern `(Tamaño)` — no separate Notion schema field for size exists, and no schema change is needed

## Ways of working

- Naylu communicates in Spanish and uses technical vocabulary naturally ("pills", "artifact", "degradado", "radios", Recharts component names)
- Iterative refinement is the working mode: changes delivered in rounds, with Naylu evaluating visually and requesting follow-up passes
- Preference for client-side recomputation over relying on Notion rollup/formula fields via MCP
- Visual references (external images, design names like "Donezo") are used to communicate aesthetic direction
- Validate code with Babel (`@babel/core` with `@babel/preset-react` and `@babel/preset-env`, installed via `npm install --no-save`) before delivering output files

## Tools & resources

- React (JSX) + Recharts for dashboard rendering
- Notion as CRM backend (four databases)
- Anthropic API MCP server for the live Notion data connection within the artifact
- Babel for local JSX syntax validation
- Vercel (connected to account, deployment pending)
- Notion MCP tool `Notion:notion-search` with collection URL `collection://367eb89c-87eb-8018-beee-000b92fb67a0` for property queries
