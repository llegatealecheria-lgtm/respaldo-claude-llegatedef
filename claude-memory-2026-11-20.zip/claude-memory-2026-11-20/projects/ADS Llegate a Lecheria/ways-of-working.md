---
name: "ways-of-working"
description: "Reporting format, change-logging conventions, decision-card structure, and the Notion/Calendar/Meta Ads tooling details (including page IDs and known gotchas) for this project"
---

## Working preferences

- Naylu prefers direct, jargon-free explanations with plain-language analogies for terms like CPL, CTR, CPM, and frequency.
- She evaluates tools and prompts independently before committing them to her permanent skill setup — test in a new chat before integrating into the skill.
- She corrects outputs that use forward-looking language for actions already completed; she prefers a changelog/bitácora format for executed changes.

## Report format

- Reports are HTML with brand color tokens: teal `#65BBB0`, mango `#FFC66E`, cream `#F2E5B3`, deep blue `#00607F`.
- Report sections: hero header, KPI grid, what-we-know/don't-know grid, creative audit table with status tags, diagnosis, decision cards, next experiment.
- Reports include a glossary using plain-language analogies for CPL, CTR, CPM, and frequency.
- Decision cards use an evidence / hypothesis / risk / alternative structure for any optimization recommendation.

## Change logging & evaluation process

- Change logging: dated bitácora entries appended to the relevant Notion campaign page; format includes change number, rationale, and follow-up reminders.
- Creative evaluation is cross-referenced against prior Notion logs, the master strategy document, and the most recent evaluation before any recommendation.

## Notion MCP — page IDs and structure

- META ADS PLANNER TEMPLATE page: `6c5eb89c87eb836da81c013c23210f37`, under "Marketing Space".
- Campaigns data source (⛽ Campañas): `collection://a08eb89c-87eb-827d-b1fc-07b152f9750c`.
- C1 · Vacacional MOFU: `7a8eb89c87eb8212be46013198c3fcc3`. The old ID `386c1b5c3edb8116a3d1dd1e0a5fda00` returns 404 — do not use.
- C2 · Vacacional TOFU: `559eb89c87eb82b3809901a55929a134`.
- C3 and C4 were previously stored as `386c1b5c3edb81de9e2fddea6786c536` and `386c1b5c3edb812fb37cfe5f210036a5` — treat as potentially stale and verify before use.
- Fetching by page ID directly is more reliable than Notion search for campaign rows.
- Appending new content: use `notion-update-page` with `command: insert_content`, `position: {type: end}`; dollar signs require backslash escaping (`\$`) to render correctly.
- Replacing large structured blocks: the full `old_str` including all whitespace must match precisely; `replace_content` on full sections is more reliable than targeted `update_content` when tables contain escaped characters.

## Other tooling

- Google Calendar connected under `llegatealecheria@gmail.com`; events created with `America/Caracas` timezone, popup reminders in minutes, optional email reminders 720 minutes ahead for high-priority checkpoints.
- Meta Ads Manager exports are processed via Excel uploads; the ad set name column has been missing from recent exports — flag this when it affects audience-level analysis.
- Desde nov 2026 Naylu conectó Meta Ads a Claude vía el conector Windsor.ai (cuenta CP2 Llegate a Lecheria), para leer datos directo sin exportar Excel.
- Pidió que cada cambio que le cuente (anuncios apagados, rotaciones) se registre en la bitácora de Notion, y que la base ⛽ Campañas se mantenga depurada y al día con las campañas realmente activas en Meta.
- The `meta-ads-trafficker` skill contains `report_html_guide.md` (brand tokens, typography, language simplification rules, reusable analogies, improvement log) and `SKILL.md` referencing the guide.
- The Claude Project stores dynamic data (prompt banks, campaign history, buyer personas, brand brief) separately from the skill, so updates to those files improve responses without modifying the skill.
- Reservations are also tracked in a separate manual form-based database ("Base de datos llegate 2026 Responses") with a "Red social" field for attribution; paid Meta Ads bookings are under-tagged there (often logged as generic "Instagram" instead of "ADS Instagram"), so ad-attributed booking counts from it likely undercount the real contribution — cross-check cautiously.
