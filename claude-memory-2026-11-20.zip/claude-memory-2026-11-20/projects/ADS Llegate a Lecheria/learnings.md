---
name: "learnings"
description: "Hard-won Meta Ads platform mechanics, scaling and evaluation rules, and creative strategy principles for this account — read before recommending any optimization"
---

## Structure & budget mechanics

- CBO outperformed ABO in direct comparison: more conversations at roughly half the CPL. ABO became structurally unaffordable due to Meta's $2/day per-ad-set minimum floor at this budget level; reverting to CBO was the unanimous recommendation.
- Changing budget structure mid-campaign resets the learning phase — minimize structural changes, especially during active delivery.
- Switching a published Advantage+ campaign (Messages objective) from CBO to ABO is not possible via toggle — it requires duplicating the campaign and selecting ad-set budget at creation time.
- Advantage+ automatic placements prevent manual deselection of individual channels (e.g. Messenger); the solution is duplicating the ad set and switching to manual placements.
- Scaling rule: 10–20% weekly increase at CBO level, with a 10% floor recommended when the remaining campaign window is short or during a scarcity phase.

## Data & reporting behavior

- Editing a live post caption blends historical CPL data — future evaluation must filter from the edit date forward and never use cumulative figures.
- Deleted ad set data is not lost in Meta Ads Manager: it is accessible by filtering reports to include deleted entities or using Ads Reporting with the relevant date range. However, a duplicated ad set restarts the algorithm's learning phase from zero.

## Evaluation framework

- Evaluation uses three layers: industry benchmarks, historical data as comparative reference (not validation), and current contextual factors — past performance is not assumed to have been optimal.
- "Stop analysis" rules should not be overly rigid — the skill guides analytical thinking rather than prescribing a fixed output structure.

## Creative strategy

- "Reducing a creative's budget share" is not a manual Meta control — it is achieved by introducing a stronger competing creative into the same ad set.
- Audience overlap between C1 and C2 is intentional, not a problem, given the funnel strategy.
- Two-wave creative approach: priority assets activate day 1, apartment-specific content enters week 2 based on CTR thresholds.
- Maximum 4–5 active creatives per ad set at budget levels typical to this account.
