---
name: "estrategia-embudo-proxima-campana"
description: "Estrategia de embudo en 3 etapas (TOFU, MOFU, retargeting) que Naylu arma para la próxima campaña de Meta Ads de Llégate a Lechería"
---

- (nov 2026) Naylu está armando la estrategia de la próxima campaña de Llégate a Lechería en 3 etapas: TOFU (público frío, apoyado en contenido orgánico existente o nuevo de Instagram), MOFU (público tibio: intereses + públicos similares basados en la data de su cuenta de Instagram) y retargeting (venta directa a públicos personalizados y base de datos de la marca)
