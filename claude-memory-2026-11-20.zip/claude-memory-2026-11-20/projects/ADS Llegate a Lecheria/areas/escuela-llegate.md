---
name: "escuela-llegate"
description: "Espacio en Notion \"Escuela Llegate a Lecheria\" con la página \"Meta Ads formaciones\" para lo aprendido en asesorías con Adrián"
---

- Naylu creó en Notion "Escuela Llegate a Lecheria" para guardar formaciones del negocio; dentro tiene la página "Meta Ads formaciones" (nov 2026), donde guarda lo aprendido en sus reuniones de asesoría de Meta Ads con Adrián
