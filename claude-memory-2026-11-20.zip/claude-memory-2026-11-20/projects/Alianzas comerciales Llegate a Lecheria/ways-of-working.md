---
name: "ways-of-working"
description: "Operating principles, negotiation and pricing rules, working preferences, and tooling for the Llégate a Lechería project"
---

## Principles and learnings
- Analysis before execution: validate numbers and logic first, then produce materials — not the reverse
- Expenses are variable, not fixed: monthly operating expenses must be pulled from dedicated ingreso/egreso sheets (e.g. "Marzo ingresosegresos"), not assumed as fixed costs; revenue comes from monthly booking sheets
- Commission structures should be expressed as minimum guaranteed percentages, not fixed dollar minimums per booking
- Margins are embedded, not disclosed: the 15–18% operational margin on gastronomic services is built into the package price and never communicated to the end client
- 18% is recommended as a starting margin, leaving room to negotiate down
- Supplier negotiation sequencing: let the supplier quote first before revealing price targets, to avoid anchoring above their floor
- Framing matters for internal stakeholders — the Notion commission page was deliberately reframed from Jera's earnings perspective rather than Naylu's internal view, as a principle of audience-appropriate communication
- Seafood is a strategic differentiator: Lechería is a coastal city and guests seek seafood options, so dishes like Linguini Fruto di Mare are kept even if they complicate standardization

## Working preferences
- Prefers direct, conversational WhatsApp language — not formal or robotic; short and human-sounding
- When given too much analysis, prefers Claude to simplify to a single clear recommended action
- Works iteratively: validates data → builds assets → refines with corrections in real time
- Uses real booking data (multi-sheet Excel with monthly tabs) as the authoritative source for financial modeling
- Produces professional branded outputs: pitch decks, meeting minutes (minutas), Notion pages, WhatsApp messages

## Tools and resources
- Notion — active CRM and documentation hub; child pages used for partner-specific content
- Notion reliable operations: `notion-update-page` with `replace_content` and `update_properties` as separate calls; child page creation via `parent: {type: 'page_id', page_id: '...'}`
- Excel multi-sheet workbook — master inventory and booking data source, organized by monthly booking sheets and separate monthly ingreso/egreso sheets
- PowerPoint (.pptx) — used for pitch decks and partner presentations, strictly branded
- PDF — used for meeting minutes (minutas) in branded format
- Gastronomic partners: Kleyopatra, El Nacional, La Casona
