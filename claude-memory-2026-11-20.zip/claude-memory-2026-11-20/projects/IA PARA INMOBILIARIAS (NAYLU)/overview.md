---
name: "overview"
description: "Proyecto de IA para asesores inmobiliarios en Venezuela — propósito, equipo y necesidades del nicho detectadas por Naylu"
---

## Propósito

- Naylu y [[angel]] (desarrollador) quieren desarrollar un producto de IA para venderle al nicho inmobiliario en Venezuela
- Objetivo: facilitarles a los asesores inmobiliarios sus procesos de ventas, captación y envío de inmuebles

## Necesidades del nicho detectadas (percepción inicial de Naylu)

- Los asesores agendan visitas y captaciones de forma manual
- Cuando un asesor pide fotos, las envía manual
- No hacen seguimiento de ventas
- Se quejan de las inspecciones de alquiler: les toma mucho tiempo llevar apartamentos en alquiler y les genera poco ingreso
- Llevan todos los recordatorios anotados en hoja y papel
- No se sabe si evalúan el potencial de una propiedad al captarla ni su potencial de venta
- El análisis de mercado parece hacerse manual; Century 21 tenía una interfaz de análisis de mercado y Naylu plantea construir una similar

## Colaboración con [[david-hernandez]]

- Naylu quiere que David Hernandez (asesor inmobiliario referente) se una al modelo de negocio de venta de sistemas al nicho, por su conocimiento y su red de contactos
- Angel propuso como producto piloto un "asistente administrativo" para presentarle a David

## Estado actual

- Etapa exploratoria: Naylu describe las necesidades como "vagas" y busca identificar más necesidades y soluciones con IA
