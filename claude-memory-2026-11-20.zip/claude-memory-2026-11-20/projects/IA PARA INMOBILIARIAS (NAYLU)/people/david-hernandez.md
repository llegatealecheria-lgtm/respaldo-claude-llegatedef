---
name: "david-hernandez"
description: "Asesor inmobiliario referente en la zona; Naylu busca que se una como validador/canal de venta del proyecto de IA para asesores inmobiliarios"
---

- Asesor inmobiliario referente en la zona de Naylu
- Tiene su propia inmobiliaria
- Ya desarrolló sus propios sistemas y está desarrollando otros con un desarrollador distinto al equipo de Naylu
- Tiene amplia red de contactos de otros asesores inmobiliarios
- Naylu percibe que tiene recelo de que el proyecto de [[overview]] compita con sus propios sistemas
