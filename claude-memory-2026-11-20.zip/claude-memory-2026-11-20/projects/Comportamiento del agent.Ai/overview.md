---
name: "overview"
description: "Purpose, scope, and current state of the Venezuelan-voice writing manual for the Llégate a Lechería AI customer service agent"
---

- Naylu is building communication and writing materials for an AI customer service agent at Llégate a Lechería, a vacation and corporate rental service based in Lechería, Anzoátegui, Venezuela
- The AI agent is a woman
- Core goal: the agent's written communication must sound authentically Venezuelan — natural to the region and to the team's established voice, not merely grammatically correct
- Scope is exclusively written communication: tone, expressions, and style
- Operational processes (payment flow, reservation confirmation, human handoff) are documented separately and fall outside this project's scope

## Current state
- A writing and communication manual has been drafted as a Markdown file intended for direct use as a system prompt
- The manual was built from scratch using three real WhatsApp chat exports (clients Alberto, Anyela, and Sebastián) as source material
- The manual includes a detailed set of mandatory writing rules covering sentence structure and comma usage
- Mandatory rules also cover specific language vices to avoid: pleonasmo, muletillas, dequeísmo, queísmo, anfibología, impropiedad, and neologismos forzados
- Naylu noted openness to further consultation to optimize the result
