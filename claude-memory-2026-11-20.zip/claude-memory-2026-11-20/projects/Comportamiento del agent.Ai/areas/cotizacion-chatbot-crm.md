---
name: "cotizacion-chatbot-crm"
description: "Cotización de chatbot + CRM con otra agencia (contacto Luis) para Llégate a Lechería"
---

- Naylu está cotizando con otra agencia (contacto: Luis) el desarrollo de un chatbot integrado a un CRM para mover clientes por el embudo de ventas de [[llegate-a-lecheria]]; quiere acompañamiento para luego gestionarlo ella misma sin depender de la agencia, y pidió dos opciones: A (desarrollo + acompañamiento) y B (además soporte mensual)
