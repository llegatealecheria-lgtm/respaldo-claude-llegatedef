---
name: "manual-decisions"
description: "Structural decisions made about the writing manual and the principles behind them"
---

- Apéndice B (templates section) was removed from the manual — templates live in a separate document
- Operational context appears in the manual only as a brief four-line appendix
- A bank of real expressions extracted from the source chats anchors the Venezuelan voice section: greetings, confirmations, mid-conversation phrases, closings, and handling of unexpected situations
- The manual includes before/after example pairs contrasting flat-but-correct text with correct-and-Venezuelan text
- All Venezuelan expressions used are drawn exclusively from the team's real chats; generic regional slang not observed in the source data is avoided

## Principles
- The central problem to solve is not grammatical correctness but authentic voice — the agent sounding generically correct is the failure mode to avoid
- Source material from real team chats is the ground truth for what "Venezuelan" means in this specific business context; generic regional slang is not a substitute
- Operational process documentation and communication style documentation are intentionally kept separate to maintain clarity of scope
