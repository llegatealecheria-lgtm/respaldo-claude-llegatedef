---
name: "notion-workspace"
description: "Structure and data source IDs for the restructured \"Ideas de contenido\" Notion workspace — current state"
---

- The Notion content planning workspace "Ideas de contenido" was recently fully restructured
- Two overlapping databases (Brainstorming Organizado + Posts) were merged into a single Posts pipeline
- New fields added to Posts: "Nivel de consciencia" (5-stage select) and "Prioridad"
- New reference database "🧭 Niveles de Consciencia (embudo)" maps each awareness stage to objectives, audience needs, content types, and examples
- New "Foco del mes" database with a monthly ritual schema — 6 self-guiding questions inserted into all five month pages (Septiembre, Octubre, Noviembre, Diciembre, Marzo)
- Brainstorming database archived; static AI prompts table archived

## Data source IDs

- Posts pipeline: `collection://be1eb89c-87eb-8373-b325-87c4c14a9bd8`
- Brainstorming (archived): `collection://50feb89c-87eb-8236-a316-0720739bc79e`
- Foco del mes: `collection://910eb89c-87eb-8270-97ba-87bf872be5e0`
- Niveles de Consciencia: `collection://a60b38cb-ce3c-465f-8e21-17802f557f84`
- Propósito/Pilares: `collection://c07eb89c-87eb-82be-aa31-07e923dcfab3`
- Main "Ideas de contenido" page ID: `3aeeb89c87eb838389b80181d51d0`
