---
name: "content-principles"
description: "Editorial principles and learnings for scriptwriting and copy — specificity, framework selection, CTA placement, cultural register"
---

- Specificity over generality: hooks must be irreplaceable — they should break if lifted and applied to a competing listing. Generic copy is consistently rejected.
- No invented information: Naylu explicitly does not want assumed or filled-in details. Missing facts (price, boat specs, reservation method) must be flagged and asked about rather than invented.
- Framework selection is diagnostic: PAS is not the default — aspirational/lifestyle content uses Contraste + Descubrimiento or Story-Solution-Offer. The framework is chosen after diagnosing the content's emotional entry point.
- Price and hard CTAs belong in one designated conversion video per campaign; organic videos stay inspirational to preserve trust and shareability.
- Property-specific copy: price contrasts (e.g., vs. hotels) should only be used where the savings are genuinely compelling. Other properties are positioned on space, comfort, or experience.
- Skills must be non-redundant: new skills are evaluated against existing ones to avoid overlap and unnecessary friction.
- Teach the reasoning: Naylu wants to understand why changes improve retention, not just receive output.
- Cultural specificity matters: details like "twelve WhatsApp chats" (not "twelve browser tabs") reflect how the local market actually behaves and are preferred over generic metaphors.
- Usa su propia numeración de niveles de consciencia en Notion (p. ej. "Most Aware nivel 4", "Solución nivel 2"), distinta de la escala de Schwartz; mantener su nomenclatura y no corregirla
- Los anfitriones solo entregan la propiedad; Llégate no resuelve todo el viaje — no prometer en el copy logística resuelta (comidas, planes), solo recomendaciones
- Hashtags must name the specific service shown: boat content gets service hashtags like #alquilerdelanchas or #rentadeyates, not just generic tourism tags
- Instagram captions: brief, cool, and less AI-sounding (e.g. "el apto que tu familia estaba buscando…" register), not storytelling-heavy
