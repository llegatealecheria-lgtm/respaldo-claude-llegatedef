---
name: "ways-of-working"
description: "How Naylu works in this project — language, output preferences, session patterns, plus the skill library and tools in use"
---

- Works entirely in Spanish (Venezuelan register); Claude responds in Spanish throughout
- Prefers inline chat editing over file artifacts for script work
- Likes multiple options with clear rationale — typically 3–4 variants with brief editorial reasoning — rather than a single output or open-ended questions upfront
- Operates iteratively and consultatively: skills are activated at session start, and a diagnostic pass (Modo Auditoría) runs before rewriting existing scripts
- Maintains a "no inventes" principle — open questions are flagged explicitly and carried forward across sessions
- Favors structured deliverables: two-column literary/technical script tables, three-tier CTAs (soft/intermediate/direct), b-roll pairing guides, and semaphore-coded audits
- References prior Claude sessions as material sources, expecting continuity across conversations

## Custom skill library

- `arquitecto-de-guiones` — scriptwriting and script auditing skill with two modes (Modo Escritura / Modo Auditoría), PAS + Contexto-Inclinación-Retroceso frameworks, semaphore audit system (🟢🟡🔴), and forbidden phrases list
- `arquitecto-de-buyer-personas` — persona-building skill tied to the Víctor Heras framework
- `meta-ads-trafficker` — paid media copy skill
- `arquitecto-de-notion` — recommended for Notion workspace restructuring tasks
- `skill-creator` — used to package and install new skills
- Skill system lives at `/mnt/skills/`; installed skills at `/mnt/skills/user/`; outputs at `/mnt/user-data/outputs`

## Tools & references

- Notion — primary content planning workspace
- Trello — previously held the awareness funnel framework, now integrated into Notion
- Víctor Heras — "500,000 seguidores" — foundational content strategy reference
- Eugene Schwartz 5-level awareness model — integrated into Notion content planning
- Senja.io — explored for testimonial/review collection per property (free plan limitations noted)
- Meta Ads — active paid media channel; `meta-ads-trafficker` skill in use
