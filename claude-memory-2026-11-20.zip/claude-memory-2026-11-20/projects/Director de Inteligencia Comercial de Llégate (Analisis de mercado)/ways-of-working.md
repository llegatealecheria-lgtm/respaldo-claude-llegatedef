---
name: "ways-of-working"
description: "Deliverable patterns, owner archetypes, document conventions, and the tools and source files behind Llégate's work"
---

## Deliverables and process
- Paired deliverables: every owner negotiation produces an external HTML report plus an internal Markdown strategy guide
- The HTML is never generated until Naylu approves a summary of findings — a mandatory pause before writing HTML
- Document scope discipline: targeted, punctual edits to existing documents are preferred — not rewrites
- Losing visual or data elements (range graphics, bar charts, detailed comparable tables) is a critical error
- Owner profile updates happen after three or four conversations, not after each one
- Onboarding de propietarios nuevos: no usan secuencia de mensajes; envían por WhatsApp el texto de términos y condiciones (respuesta "ACEPTO") junto con el PDF "Propuesta propietarios"
- The validation log's most important column is the exact phrase used — not whether the owner accepted
- Correction-forward working style: Naylu flags errors immediately and expects implementation without re-explanation; she catches data skew and expects methodology to be stated explicitly, distinguishing exact data from derived estimates

## Owner archetypes
- Six owner archetypes drive negotiation strategy: Inversionista de Portafolio Rígido, Representante de Propietario Ausente (Proxy), Delegador Familiar, Controlador/Experto Autopercibido, Optimista Estacional, Propietario Nuevo/No Materializado
- Archetypes mix three axes (who decides, how they price, tenure), so primary + secondary trait combinations are valid
- Language rules and objection scripts are tailored per archetype

## Format preferences
- Markdown for internal/context-loading files; HTML for human-facing deliverables
- Formal usted Spanish for all owner-facing documents
- Compact, digestible documents over exhaustive ones
- Brand palette: teal #65BBB0, gold #FFC66E, cream #F2E5B3, navy/petrol #00607F

## Internal source files (authoritative — always use these, never re-derive from raw sheets alone)
- `Inventario_maestro_usado_por_Jera_IA` — sole authoritative source for pricing data
- `Benchmark_Llegate_Unidades_y_Precios` (sheet "Base (espejo Notion)", header row 4, matching via the "Comparable con:" column)
- `Identificacion_Unidades_Ingresos_2026_FINAL.xlsx` (sheet "Ingresos 2026 — Identificado") — unit-level attribution source
- `Ingresos_Llegate_9.xlsx` — billing records (counts payments, not reservations)
- `_Base_de_datos_llegate_2026` — reservation records (counts reservations, not payments)
- `Manual_Costos_Llegate.md` — cost terminology, margins, ceiling formula, per-unit reference table
- `Ficha_Propietario_Negociacion_Llegate_IA.xlsx` — 11 owner profiles with archetype synthesis
- `Avatar_Propietario_Llegate_UNIFICADO` — owner archetype reference

## Tools and external data
- Skill: `analista-de-mercado-llegate` — a multi-file skill package with references for comparability/adjustments, demand/rotation, pricing/seasons, and focus portfolio
- AirDNA (free tier, submarket code 85291, labeled "Anzoátegui" but geographically Lechería); median ADRs: 1BR ~$41.50, 2BR ~$57.50, 3BR ~$62.50 — directional reference only
- AirDNA occupancy rate is locked behind the paid plan; an "Ocupación Implícita" estimate can be derived from ADR and annual income figures
- PDF generation via wkhtmltopdf; reliable vertical mobile-format pattern: `--page-width 100mm --page-height 200mm` with zero margins, `--disable-smart-shrinking`, `--zoom 0.52`, CSS `page-break-after:always` on every section
- Logo embedded as base64 to prevent asset loading failures; image verification via `pdftoppm -png -r 90`
- Notion connected via MCP (workspace llegatealecheria@gmail.com); Cartera de Propiedades database ID `367eb89c-87eb-8043-8920-cbe07a479caf`
- Notion formula/rollup columns are not accessible via query — they require per-page fetch or export
- Documenta los formatos de Llégate en Notion, página "Formatos of LAL" → base "Glosario de formatos" (plantilla por entrada: Ficha · Info de interés · Paso a paso); quiere que los formatos de este proyecto estén cargados ahí
- El avatar de propietarios, los arquetipos y la bitácora de validación viven ahora en el Google Sheet "AVATAR Y BITÁCORA DE VALIDACIÓN"
- Para propietarios nuevos o por captar quiere dos informes separados: uno de recomendaciones de mejora del apto y otro de precios (tarifa de aliado comercial distinta a la del cliente directo, temporada baja/alta, semana, 15 días, mes) con la propuesta de anfitrionaje; la evidencia de mercado sigue el modelo del informe de Balbina, con enlaces clicables y fotos de la competencia, y los enlaces de Airbnb se los envía Claude por el chat para que ella los valide antes de ponerlos en el informe
- Informes de precios a propietarios siempre en euros; ella misma captura las fotos de la competencia y quiere que Claude se las vaya solicitando
- Antes de fijar tarifas de un propietario, preguntarle siempre cuánto le quiere ganar a la propiedad (con sugerencia interna de margen); regla fija: el propietario siempre debe dar precio de aliado
- Las sugerencias de precio basadas solo en Airbnb no la convencen: quiere cotizar propiedades nuevas partiendo del historial de tarifas de aliado del estándar corporativo (carpeta de propuestas de estadías largas), alineando características similares del inmueble (ej. tomó Costa Guaica de Argenis como referencia para Katiuska); el precio del checklist de propiedades es el costo de aliado del propietario
- Prefiere el diseño del informe de Balbina (no el de Luz León) para las propuestas de precios a propietarios; la tarifa de anfitrionaje estándar es 15 € por reserva, sin tarifa preferencial tachada ni bloque de "Término"
