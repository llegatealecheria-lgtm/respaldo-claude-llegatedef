---
name: "estadias-largas"
description: "Política de precios y comisión de Llégate para estadías largas (6+, 15+, 30+ noches) en el catálogo corporativo; formato de Alquila en Lechería"
---

- Para estadías de 30+ noches, la comisión de Llégate puede ser de $10 por noche
- Decidió no usar el Excel de costos de ventas (fee de gestión, comisión por tamaño) porque no lo entiende; usar solo el formato de precios de Alquila en Lechería (precio por noche por tramo: noches cortas, 1 semana, 15 días, 1 mes)
- Los cálculos de estadías largas van sin IVA
- Le interesan los descuentos por estadía para 6+, 10+ y 15+ noches, empezando por las unidades del catálogo corporativo (ver [[catalogo-corporativo]])
- Quiere proponer a propietarios una promoción opcional entre semana: descuento de $10 o $15 por noche de lunes a jueves, que baja el propietario al 100% (Llégate no cede nada); descartó la promoción de fidelidad (primer y segundo regreso)
- Prepara un PDF de propuesta de estadías largas para propietarios (uno por propietario, más un maestro interno); en la tabla de mercado no nombrar Hostaway ni el hotel de estadía extendida
- Para Guaicamar B1-21 agregó un tramo de 10 a 14 noches y dejó el mes sin cambio; luego aclaró que esa unidad maneja precio por personas (4 pax $50, 6 pax $65, 8 pax $85) y pidió que las tarifas por tramo lo reflejen
- Comisión de Llégate por tramo: unidades chicas (Victoria Park, Solmar 902, Esmeralda 402, Guaica Suites 423) $15 de 3 noches hasta la semana, $12 a 15 noches, $10 al mes; unidades grandes de más de 2 habitaciones (Guaicamar, Costa Guaica) siguen en $20
- En estadías de 3 a 6 noches el precio baja $5 en todas las unidades; en la promo entre semana Llégate cobraría una comisión mínima que no se muestra al propietario
- En el PDF a propietarios el cuadro de reservas, noches y ocupación solo se muestra en Costa Guaica y Guaicamar; va a enviar reservas, noches y facturado por propiedad y la ocupación la calcula Claude
- Ya envió el histórico de Costa Guaica (Argenis) y su página quedó completa; los datos de Guaicamar B1-21 siguen pendientes de actualizar
- Pidió también un PDF para Yuliditza Goitia, propietaria de Entremares (Torre G, Grupo B en certificación)
