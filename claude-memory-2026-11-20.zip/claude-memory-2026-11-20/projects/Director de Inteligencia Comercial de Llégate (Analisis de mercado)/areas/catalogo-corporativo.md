---
name: "catalogo-corporativo"
description: "Catálogo corporativo de Llégate a Lechería para empresas de corporate stay — 11 unidades, 3 certificadas hoy, prompt para Claude Design en curso"
---

- Construyendo un catálogo corporativo dirigido a empresas de corporate stay, inspirado en los catálogos de Guaica Suites (tono elegante/informativo) y Thai (descartado por tono muy turístico/juguete)
- 11 unidades candidatas: Guaica Suites 423 (David), Guaicamar B1-21 (Balbina), Guaicamar J113 (Jair), Solmar 902 (Andreina), Victoria Park (Gabriela), Thai K-PB5 (Dalcira), Thai C-PH8 (Alexis), Guaicamar E1-14 (Isidra), Costa Guaica (Argenis), Plaza Guaica 3-6-1 (Johanna), Entremares Torre G (Yuliditza)
- Solo 3 unidades pasan el formulario de certificación sin pendientes: Guaica Suites 423, Guaicamar B1-21, Guaicamar J113 — decidió incluir las 11 en el catálogo igual, agrupadas por estado (disponible ahora / en proceso de certificación)
- Mínimo de noches corporativo: 3. Escalones: 3-6 noches tarifa estándar, 7-29 noches tarifa corporativa con descuento (sin definir), 30+ a cotizar
- Ninguna propiedad de la cartera tiene planta eléctrica de respaldo
- Política de cancelación turística existente no se traslada tal cual a corporativo — pendiente de definir la versión corporativa
- Pendientes declarados: factura fiscal, kit ejecutivo (contenido y precio), protocolo de incidencia/SLA de respuesta, contacto (nombre y WhatsApp) para el catálogo
</content>
<parameter name="if_version">new
