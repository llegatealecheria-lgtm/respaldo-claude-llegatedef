---
name: "negociacion-maria-francia"
description: "Negociación de precio con la propietaria Maria Francia por su unidad Guaica Suites 131 (1 hab, cap. 5)"
---

- Primera negociación con la propietaria Maria Francia
- Costo actual de Maria Francia en Guaica Suites 131: $55/noche
- Quiere que el costo baje a $45/noche
- Maria Francia también tiene otra unidad en Solmar (no incluida en esta negociación)
