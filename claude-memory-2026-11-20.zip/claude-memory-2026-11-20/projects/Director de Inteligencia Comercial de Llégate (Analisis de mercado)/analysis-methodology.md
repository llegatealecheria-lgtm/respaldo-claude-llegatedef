---
name: "analysis-methodology"
description: "Data attribution rules, benchmark adjustments, and analytical principles for Llégate pricing and rotation analysis"
---

- Reservation attribution must be unit-level, not conjunto-level
- The monthly Ingresos sheets only record the complex name — unit-level attribution for ambiguous buildings (especially Guaica Suites, Doral Beach, Thai) must come from Identificacion_Unidades_Ingresos_2026_FINAL.xlsx using the ID column
- Attributing by conjunto causes critical errors (e.g., assigning Ana Karina's reservations to Joes or another owner in the same building)
- The two income sources will never match by count: the client database counts reservations; Ingresos_Llegate counts billing events (always higher, includes referrals, split payments, extended stays)
- These two counts must never be cited as if from the same count; rotation comes from the client base, income comes from a cross-reference join by client + check-in date
- Airbnb comparables require a 15.5% host commission adjustment: the net to the host (published price × 0.845) is what competes against the owner's costo base — never the gross published price
- Airbnb is eliminating the split-fee model (effective ~September–October 2026), making 15.5% the universal standard going forward
- Benchmark data must never be hardcoded in skill files — all counts and figures must be re-derived from live source files at analysis time
- Success cases must be unit-level validated
- The validated internal success case is Alexis Márquez (Thai, known as Thai/Alexis) — validated via cross-reference
- David Hernández (Guaica Suites) is explicitly disqualified as a success case because he charges the same price as Maria Francia
- Ana Karina's Thai units involve a third-party intermediary with an embedded per-night fee — Naylu negotiates with the intermediary, not the owners directly
- Benchmark divergence rule: when comparables within a complex diverge more than 30% in price per person, no price verdict is issued — the analysis shifts to rotation; Puerto Morro is the documented case
- High-season data requires mandatory verification: confirm that the high-season costo base actually exceeds the low-season costo base before reasoning with it (documented with Balbina's units)
- Opening arguments anchor to current market comparables, never to what the owner accepted in the past
- The occupancy argument is mandatory when rotation data is weak: lowering price costs nothing on nights that would have gone vacant
- Persuasion through evidence only — no manipulative framing
