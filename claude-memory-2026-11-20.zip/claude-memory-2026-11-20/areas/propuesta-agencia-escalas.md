---
name: "propuesta-agencia-escalas"
description: "Propuesta comercial de Llégate a Lechería para una agencia de viajes aliada — hospedajes cortos (1-3 noches) por escala de vuelo"
---

- Propuesta dirigida a una agencia de viajes aliada; el caso de uso es hospedaje por escala de vuelo, con estadías mínimas de 1 a 3 noches máximo
- Planes divididos en dos categorías: Standard y Premium
- Standard: Vientos del Mar (Francisco), Thai (Dalcira), Solmar (Andreina), Plaza Guaica (Joanna)
- Premium: Entremares, Marina del Rey y Marinamar
- Adicionales de Standard (backup si los principales no están disponibles): Guaica Suites, Esmeralda (David), Victoria Park (Gabriela) y Guaicamar
- Marinamar no está confirmada aún — parte del objetivo de la propuesta es venderle a esa propietaria las estadías cortas para que las acepte
- Ambos planes incluyen traslado aeropuerto-apartamento y apartamento-aeropuerto (tarifa fija)
- Diferenciador Standard: kit de abastecimiento sencillo, aún en armado
- Diferenciador Premium: platos específicos preparados por aliados gastronómicos (shawarmas, hamburguesas, desayunos ejecutivos, almuerzos, cenas)
- Entregable pedido: presentación interactiva; quiere minimizar rondas de corrección

- La agencia aliada es Blessing Travel; el modelo ya negociado es un porcentaje sobre el pago (la estructura del porcentaje ya se les entregó en una conversación previa)
- Blessing Travel procesa el pago completo del cliente y remite a Llégate la totalidad cotizada
- El volumen de pasajeros lo definirá la agencia al recibir esta propuesta
- Aplican los precios habituales de cada propiedad; esta modalidad opera en paralelo a la estructura de precios vigente y no hay recargo por estadía de 1 noche
- Las propiedades seleccionadas van de 2 a 6 personas
- La limpieza se cobra según lo maneje cada propiedad; si la propiedad no la maneja, no aplica
- El traslado es ida y vuelta (cubre los dos viajes del huésped) e incluye un margen interno que no debe revelarse a la agencia ni aparecer desglosado
- El kit Standard va incluido en el plan y es descartable si el huésped no lo quiere; contenido aún en definición, se adapta al huésped
- Los platos de aliados gastronómicos tienen horarios definidos, suficientes para pedir cena
- Las propiedades elegidas ya aceptan horarios de madrugada; a las que no, se busca convencerlas con la ocupación garantizada
- Disponibilidad sujeta a consulta (no hay cupo bloqueado); se prioriza responder rápido
- Política: nunca hay devolución, sí reprogramación siempre que sea posible
- La presentación se expone en reunión, con todo a la vista, incluyendo Marinamar como Premium, y sin imágenes por ahora
- Aliados gastronómicos confirmados: Kleyopatra (cena hasta las 11:00 pm — shawarma mixto, shawarma trimixto, hamburguesa bacon con papas, precio único) y El Nacional (desde las 8:30 am — desayunos y almuerzos ejecutivos)
- Desayunos El Nacional, dos opciones seleccionables: (a) carne mechada, perico, arepa asada y tajadas; (b) solomo al grill, huevo frito y arepa
- Almuerzos El Nacional, todos incluyen sopa; dos opciones: (a) sopa + pabellón oriental; (b) sopa + arroz, asado negro y ensalada de pollo
- El kit de abastecimiento subió de precio y debe quedar como casilla editable en la presentación
- Fotos referenciales de shawarma, hamburguesa, desayuno y almuerzo entregadas para la presentación (desayuno y almuerzo son referenciales porque el menú rota)
- Tarifas por noche fijadas en la propuesta — Standard: Vientos del Mar 65, Thai 80, Solmar 80, Plaza Guaica 85, Guaica Suites 70, Esmeralda 70, Victoria Park 60, Guaicamar 95; Premium: Entremares 95, Marina del Rey 110, Marinamar 135
- La limpieza es seleccionable por propiedad: en algunas se puede suprimir y en otras no
- Plan Standard incluye apartamento completo, traslado aeropuerto-apartamento-aeropuerto, y kit de abastecimiento o plato de aliado a elección; Premium añade condominios y propiedades de categoría superior
- Entregable final es una presentación HTML interactiva con calculadora de cotización en vivo y selector de comidas
