---
name: "visuarte"
description: "Naylu's content and editorial work for Visuarte, a Gen Z–focused Latin American digital media outlet"
---

- Digital media outlet targeting Gen Z in Latin America; Naylu does content and editorial work for it
- Developed editorial captions across TikTok, Twitter/X, and web (topics: Disney live action, Álvaro Díaz's *Omakase*, Met Gala 2026)
- Strict editorial preferences: against mirror language and headline-body redundancy
- Produced a 10-slide investor pitch deck selling the brand vision
- Has a web portal in addition to TikTok and Twitter/X
- Editorial standards: informative over subjective captions, 700–900 character limit, natural closing questions, and tone aligned with Visuarte's brand identity (creative, ambitious, audacious yet professional)
