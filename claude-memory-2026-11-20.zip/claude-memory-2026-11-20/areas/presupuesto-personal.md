---
name: "presupuesto-personal"
description: "Registro recurrente de gastos personales de Naylu — mapeo de categorías de su Excel de gastos crudo (Gastosssss.xlsx) hacia las subcategorías fijas de su Excel madre de presupuesto (pestañas mensuales), y lógica de detección de duplicados"
---

- Naylu tiene un Excel "madre" de presupuesto personal 2025-2026 con pestañas por mes (fila 54 en adelante para transacciones) y un Excel crudo de gastos (Gastosssss.xlsx) que quiere pasar al madre sin duplicar, cada vez que ella lo ordene
- Los gastos del negocio Llégate mezclados en su excel personal (categorías Otros, Pauta, ADS: pago de Claude, dominio, pauta, sello, oficina, etc.) deben excluirse del presupuesto personal
- Dentro de la categoría "Ahorro cumpleaños 🎁" de su excel de gastos: las cuotas de Cashea van a "Pago de Deudas", el resto de items se revisan caso por caso con ella antes de registrar
</content>
