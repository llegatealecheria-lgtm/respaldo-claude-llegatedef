---
name: "conferencia-ia-noviembre-2026"
description: "Material de repaso de la conferencia de IA y marketing (14 nov 2026, Caracas) — Wilma Núñez, Valeria Ruiz y otros ponentes"
---

- Asistió a una conferencia de marketing digital e IA el 14 de noviembre de 2026 con exponentes como Wilma Núñez y Valeria Ruiz (fundadora de Amarillo Creativo, ponencia "Licencia para matar")
- Está armando material de repaso ponente por ponente a partir de las fotos de las diapositivas: primero versiones generales para reenviar a distintos modelos de negocio (sin datos de [[llegate-a-lecheria]]), luego un resumen completo y al final una versión para Llégate
