---
name: "manual-atencion-ia-llegate"
description: "Manual de redacción y flujo conversacional para un agente de atención al cliente con IA de Llégate a Lechería, basado en chats reales de WhatsApp"
---

- Quiere un manual para un agente de atención al cliente con IA, usando 3 chats de WhatsApp reales como base de tono y contenido
- El manual debe cumplir reglas obligatorias de redacción: usar comas en vez de "y...y...y", variar longitud de oraciones, una idea por frase/párrafo, y evitar vicios del lenguaje (pleonasmo, muletillas repetidas, dequeísmo, queísmo, anfibología, impropiedad, neologismos forzados)
- Prioridad: que el resultado suene natural, como lo diría una persona real, no robótico
- Está abierta a consultas y consejos del asistente para optimizar el resultado
- Formato de entrega elegido: Markdown/texto plano, listo para pegar como prompt de sistema
- Alcance del agente IA: solo conversa y cotiza; un humano del equipo cierra el pago y confirma la reserva
- Se construyó desde cero, sin versión previa de este manual
- La agente IA es mujer
- Corrigió el enfoque del manual: menos énfasis en personalidad/proceso operativo (ya establecido en otro lado) y más en redacción y comunicación general, porque el problema real es que el texto no suena con la esencia venezolana característica de la marca
