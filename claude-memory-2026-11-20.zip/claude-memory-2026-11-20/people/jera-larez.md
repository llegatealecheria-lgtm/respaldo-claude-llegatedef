---
name: "jera-larez"
description: "Naylu's sales advisor for Llégate a Lechería"
---

- Naylu's sales advisor for Llégate a Lechería
- Paid a 20% sales commission (Llégate's largest recurring expense category)
- Professional profile (employers, dates, agreed PM framing, CV design decisions) is stored inside the PM-expert skill at `references/perfil-jera-larez.md`
- Es quien contacta los leads de captación de propietarios (nov 2026): primer contacto, un seguimiento si no responden y, si siguen sin responder al día siguiente, se descalifican
