---
name: "david"
description: "Propietario que diseñó una app para que anfitriones gestionen sus apartamentos (ingresos, check-in/check-out); Naylu explora ser vendedora con comisión"
---

- Es propietario y diseñó una app para que propietarios/anfitriones de alquiler vacacional gestionen sus apartamentos, contabilicen ingresos y controlen check-in/check-out
- Naylu está en conversaciones con él para venderle la app a los propietarios de su cartera (Llégate a Lechería) a cambio de comisión, sin exclusividad
