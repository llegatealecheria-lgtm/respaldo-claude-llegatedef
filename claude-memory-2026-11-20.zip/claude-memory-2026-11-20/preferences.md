---
name: "preferences"
description: "How Naylu wants Claude to respond"
---

- Communicates naturally in informal Venezuelan Spanish
- Prefers bullet points, comparative layouts, and concise labeled formats over dense prose
- For university presentation prep: prefers PDF study guides with bullet points, example spoken phrases, and real-world cases; skip quiz or interactive formats entirely
- Editorial writing: avoid mirror language and headline-body redundancy
- When working on CVs or profile optimization, ask exploratory background questions before restructuring (e.g., unlisted experience, unmentioned achievements, relevant personal projects) rather than assuming the source document is complete
- Video subtitles: never invent words when unsure of what she says — ask her with the exact second and she'll say it
- Video editing for TikTok: prefers flipping the video so she appears on the right and overlays go on the left, so TikTok's reaction buttons don't cover them
